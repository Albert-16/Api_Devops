﻿using EasyTemplateSolution.Application.Service;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Concrete;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.SUNITP_ServiceReference;
using Infrastructure.Repositories;
using Infrastructure.Utillities;
using System;

namespace Application
{
    public class ConsultaCuentasFavoritosService
    {

        private readonly ISunitpService _iSunitpService;
        public ConsultaCuentasFavoritosService()
        {
            _iSunitpService = new SunitpService();
            _iSunitpService.SetInt("LAYER_3", "LAY_3_MS_35", "MICROSERVICIO CONSULTA CUENTAS FAVORITOS", "MICROSERVICIO CONSULTA CUENTAS FAVORITOS");
            _iSunitpService.AddSingleLog("INICIO DEL PROCESAMIENTO");
        }

        public DataTransferObject DoProcess(DataTransferObject dataTransferObject)
        {
            DataTransferObject dataTransferObjectResponse = new DataTransferObject
            {
                Bank = "HN",
                ExecuteMethod = dataTransferObject.ExecuteMethod,
                Error = "00000000000000000000",
                ExternalError = "PROCESO REALIZADO CORRECTAMENTE"
            };
            try
            {
                EasyDataProcessFactory edpf = new EasyDataProcessFactory();
                edpf.RegisterRepository(_iSunitpService, "LAY_3_MS_35_M_0_TEST_CONNECTION", new TestConnectionRepository());
                edpf.RegisterRepository(_iSunitpService, "LAY_3_MS_35_M_1_CONSULTA_CUENTAS_INSCRITAS", new ConsultaCuentasFavoritosRepository2());
                

                //DoProcess
                dataTransferObjectResponse = edpf.DoProcess(_iSunitpService, dataTransferObject);
                _iSunitpService.SetIndicators(Indicator.SUCCESS, ActionType.OK);
            }
            catch(Exception ex)
            {
                _iSunitpService.SetIndicators(Indicator.FAIL, ActionType.ERROR);
                _iSunitpService.AddSingleLog(ExceptionLogger.GetException(ex));
            }

            _iSunitpService.AddObjLog("ConsultaCuentasFavoritosService DoProcess", dataTransferObjectResponse.Data.Error, dataTransferObjectResponse.Data.ExternalError, dataTransferObjectResponse);
            _iSunitpService.AddSingleLog("FIN DEL PROCESAMIENTO");
            _iSunitpService.SaveLog();

            return dataTransferObjectResponse;
        }


    }
}
