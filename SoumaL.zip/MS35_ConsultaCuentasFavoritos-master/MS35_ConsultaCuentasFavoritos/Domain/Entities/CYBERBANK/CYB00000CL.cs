﻿using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data;
using System.Data.OleDb;

namespace Domain.Entities.CYBERPGM
{
    public class CYB00000CL : EasyMappingTool
    {
        public CYB00000CL()
        {
            SetClProgram("CYBERPGM", "CYB00000CL");

            EasyParameter idServicio = new EasyParameter
            {
                field = "idServicio",
                type = OleDbType.VarChar,
                size = 64,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(idServicio);

            EasyParameter status = new EasyParameter
            {
                field = "status",
                type = OleDbType.VarChar,
                size = 10,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(status);
        }
    }
}

