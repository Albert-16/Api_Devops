using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data;
using System.Data.OleDb;

namespace Domain.Entities
{
    public class CYB00035CL : EasyMappingTool
    {
        public CYB00035CL()
        {
            SetClProgram("CYBERPGM", "CYB00035CL");

            EasyParameter nombreOperacion = new EasyParameter
            {
                field = "nombreOperacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(nombreOperacion);

            EasyParameter total = new EasyParameter
            {
                field = "total",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(total);

            EasyParameter jornada = new EasyParameter
            {
                field = "jornada",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(jornada);

            EasyParameter canal = new EasyParameter
            {
                field = "canal",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(canal);

            EasyParameter modoDeOperacion = new EasyParameter
            {
                field = "modoDeOperacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(modoDeOperacion);

            EasyParameter usuario = new EasyParameter
            {
                field = "usuario",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(usuario);

            EasyParameter perfil = new EasyParameter
            {
                field = "perfil",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(perfil);

            EasyParameter versionServicio = new EasyParameter
            {
                field = "versionServicio",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(versionServicio);

            EasyParameter idTransaccion = new EasyParameter
            {
                field = "idTransaccion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(idTransaccion);

            EasyParameter idSesion = new EasyParameter
            {
                field = "idSesion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(idSesion);

            EasyParameter codIdioma = new EasyParameter
            {
                field = "codIdioma",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codIdioma);

            EasyParameter valOrigen = new EasyParameter
            {
                field = "valOrigen",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valOrigen);

            EasyParameter codPais = new EasyParameter
            {
                field = "codPais",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codPais);

            EasyParameter valVersionApp = new EasyParameter
            {
                field = "valVersionApp",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valVersionApp);

            EasyParameter tipoIdentificacion = new EasyParameter
            {
                field = "tipoIdentificacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(tipoIdentificacion);

            EasyParameter numeroIdentificacion = new EasyParameter
            {
                field = "numeroIdentificacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(numeroIdentificacion);

            EasyParameter cantidadRegistros = new EasyParameter
            {
                field = "cantidadRegistros",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(cantidadRegistros);

            EasyParameter estadoCuentaACH = new EasyParameter
            {
                field = "estadoCuentaACH",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(estadoCuentaACH);

            EasyParameter codigoBanco = new EasyParameter
            {
                field = "codigoBanco",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codigoBanco);

            EasyParameter cuentaACH = new EasyParameter
            {
                field = "cuentaACH",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(cuentaACH);

            EasyParameter tipoCuentaACH = new EasyParameter
            {
                field = "tipoCuentaACH",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(tipoCuentaACH);

            EasyParameter codMoneda = new EasyParameter
            {
                field = "codMoneda",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codMoneda);

            EasyParameter valNombreTitular = new EasyParameter
            {
                field = "valNombreTitular",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valNombreTitular);

            EasyParameter valNumeroIdentificacionDestino = new EasyParameter
            {
                field = "valNumeroIdentificacionDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valNumeroIdentificacionDestino);

            EasyParameter valCuentaDestino = new EasyParameter
            {
                field = "valCuentaDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valCuentaDestino);

            EasyParameter valAlias = new EasyParameter
            {
                field = "valAlias",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valAlias);

            EasyParameter codTipoCuentaDestino = new EasyParameter
            {
                field = "codTipoCuentaDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codTipoCuentaDestino);

            EasyParameter codTipoTransaccion = new EasyParameter
            {
                field = "codTipoTransaccion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codTipoTransaccion);

            EasyParameter RegistroSiguiente = new EasyParameter
            {
                field = "registroSiguiente",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(RegistroSiguiente);

            EasyParameter valNombre = new EasyParameter
            {
                field = "valNombre",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valNombre);

            EasyParameter valValor = new EasyParameter
            {
                field = "valValor",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valValor);

            EasyParameter caracterAceptacion = new EasyParameter
            {
                field = "caracterAceptacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(caracterAceptacion);

            EasyParameter ultimoMensaje = new EasyParameter
            {
                field = "ultimoMensaje",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(ultimoMensaje);

            EasyParameter codMsgRespuesta = new EasyParameter
            {
                field = "codMsgRespuesta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(codMsgRespuesta);

            EasyParameter msgRespuesta = new EasyParameter
            {
                field = "msgRespuesta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(msgRespuesta);

            EasyParameter valTalonRegistroAnterior = new EasyParameter
            {
                field = "valTalonRegistroAnterior",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(valTalonRegistroAnterior);

            EasyParameter archivoContinuacion = new EasyParameter
            {
                field = "archivoContinuacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(archivoContinuacion);

            EasyParameter codigoDeBanco = new EasyParameter
            {
                field = "codigoDeBanco",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codigoDeBanco);

            EasyParameter tipoDeCuenta = new EasyParameter
            {
                field = "tipoDeCuenta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(tipoDeCuenta);

            EasyParameter codigoDeRuta = new EasyParameter
            {
                field = "codigoDeRuta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codigoDeRuta);

            EasyParameter numeroDeCuenta = new EasyParameter
            {
                field = "numeroDeCuenta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(numeroDeCuenta);

            EasyParameter tipoDeIdentificacionCuenta = new EasyParameter
            {
                field = "tipoDeIdentificacionCuenta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(tipoDeIdentificacionCuenta);

            EasyParameter numeroDeIdentificacionCuenta = new EasyParameter
            {
                field = "numeroDeIdentificacionCuenta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(numeroDeIdentificacionCuenta);

            EasyParameter nombreCliente = new EasyParameter
            {
                field = "nombreCliente",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(nombreCliente);

            EasyParameter alias = new EasyParameter
            {
                field = "alias",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(alias);

            EasyParameter valBancoDestino = new EasyParameter
            {
                field = "valBancoDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valBancoDestino);

            EasyParameter descripcion = new EasyParameter
            {
                field = "descripcion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(descripcion);

            EasyParameter estado = new EasyParameter
            {
                field = "estado",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(estado);

            EasyParameter codigoRechazo = new EasyParameter
            {
                field = "codigoRechazo",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codigoRechazo);

            EasyParameter valBanco = new EasyParameter
            {
                field = "valBanco",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valBanco);

            EasyParameter valFechaHoraCreacion = new EasyParameter
            {
                field = "valFechaHoraCreacion",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valFechaHoraCreacion);

            EasyParameter valCuentaOrigen = new EasyParameter
            {
                field = "valCuentaOrigen",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valCuentaOrigen);

            EasyParameter familia = new EasyParameter
            {
                field = "familia",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(familia);

            EasyParameter tipoProducto = new EasyParameter
            {
                field = "tipoProducto",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(tipoProducto);

            EasyParameter grupoProducto = new EasyParameter
            {
                field = "grupoProducto",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(grupoProducto);

            EasyParameter codigoProducto = new EasyParameter
            {
                field = "codigoProducto",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codigoProducto);

            EasyParameter monedaOrigen = new EasyParameter
            {
                field = "monedaOrigen",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(monedaOrigen);

            EasyParameter tipoCtaDestino = new EasyParameter
            {
                field = "tipoCtaDestino" +
                "",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(tipoCtaDestino);

            EasyParameter contEmails = new EasyParameter
            {
                field = "contEmails",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(contEmails);

            EasyParameter contRegist = new EasyParameter
            {
                field = "contRegist",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(contRegist);

            EasyParameter contRegDAVIVI = new EasyParameter
            {
                field = "contRegDAVIVI",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(contRegDAVIVI);

            EasyParameter contRegSINPE = new EasyParameter
            {
                field = "contRegSINPE",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(contRegSINPE);

        }
    }
}
