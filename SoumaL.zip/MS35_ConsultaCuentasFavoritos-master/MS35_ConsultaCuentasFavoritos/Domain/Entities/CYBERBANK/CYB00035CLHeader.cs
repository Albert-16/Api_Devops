using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.CYBERPGM
{
    public class CYB00035CLHeader : EasyMappingTool
    {
        public CYB00035CLHeader()
        {
           
                var nombreOperacion = new EasyParameter();
                nombreOperacion.field = "nombreOperacion";
                nombreOperacion.type = OleDbType.VarChar;
                nombreOperacion.size = 100;
                nombreOperacion.scale = 0;
                nombreOperacion.parameterDirection = ParameterDirection.InputOutput;
                nombreOperacion.value = "";
                AddParameter(nombreOperacion);

                var total = new EasyParameter();
                total.field = "total";
                total.type = OleDbType.VarChar;
                total.size = 100;
                total.scale = 0;
                total.parameterDirection = ParameterDirection.InputOutput;
                total.value = "";
                AddParameter(total);

                var caracterAceptacion = new EasyParameter();
                caracterAceptacion.field = "caracterAceptacion";
                caracterAceptacion.type = OleDbType.VarChar;
                caracterAceptacion.size = 100;
                caracterAceptacion.scale = 0;
                caracterAceptacion.parameterDirection = ParameterDirection.Output;
                caracterAceptacion.value = "";
                AddParameter(caracterAceptacion);

                var ultimoMensaje = new EasyParameter();
                ultimoMensaje.field = "ultimoMensaje";
                ultimoMensaje.type = OleDbType.VarChar;
                ultimoMensaje.size = 100;
                ultimoMensaje.scale = 0;
                ultimoMensaje.parameterDirection = ParameterDirection.Output;
                ultimoMensaje.value = "";
                AddParameter(ultimoMensaje);

                var idTransaccion = new EasyParameter();
                idTransaccion.field = "idTransaccion";
                idTransaccion.type = OleDbType.VarChar;
                idTransaccion.size = 100;
                idTransaccion.scale = 0;
                idTransaccion.parameterDirection = ParameterDirection.InputOutput;
                idTransaccion.value = "";
                AddParameter(idTransaccion);

                var codMsgRespuesta = new EasyParameter();
                codMsgRespuesta.field = "codMsgRespuesta";
                codMsgRespuesta.type = OleDbType.VarChar;
                codMsgRespuesta.size = 100;
                codMsgRespuesta.scale = 0;
                codMsgRespuesta.parameterDirection = ParameterDirection.Output;
                codMsgRespuesta.value = "";
                AddParameter(codMsgRespuesta);

                var msgRespuesta = new EasyParameter();
                msgRespuesta.field = "msgRespuesta";
                msgRespuesta.type = OleDbType.VarChar;
                msgRespuesta.size = 100;
                msgRespuesta.scale = 0;
                msgRespuesta.parameterDirection = ParameterDirection.Output;
                msgRespuesta.value = "";
                AddParameter(msgRespuesta);

                var cantidadRegistros = new EasyParameter();
                cantidadRegistros.field = "cantidadRegistros";
                cantidadRegistros.type = OleDbType.VarChar;
                cantidadRegistros.size = 100;
                cantidadRegistros.scale = 0;
                cantidadRegistros.parameterDirection = ParameterDirection.InputOutput;
                cantidadRegistros.value = "";
                AddParameter(cantidadRegistros);

                var valTalonRegistroAnterior = new EasyParameter();
                valTalonRegistroAnterior.field = "valTalonRegistroAnterior";
                valTalonRegistroAnterior.type = OleDbType.VarChar;
                valTalonRegistroAnterior.size = 100;
                valTalonRegistroAnterior.scale = 0;
                valTalonRegistroAnterior.parameterDirection = ParameterDirection.Output;
                valTalonRegistroAnterior.value = "";
                AddParameter(valTalonRegistroAnterior);

                var archivoContinuacion = new EasyParameter();
                archivoContinuacion.field = "archivoContinuacion";
                archivoContinuacion.type = OleDbType.VarChar;
                archivoContinuacion.size = 100;
                archivoContinuacion.scale = 0;
                archivoContinuacion.parameterDirection = ParameterDirection.Output;
                archivoContinuacion.value = "";
                AddParameter(archivoContinuacion);

                var codigoDeBanco = new EasyParameter();
                codigoDeBanco.field = "codigoDeBanco";
                codigoDeBanco.type = OleDbType.VarChar;
                codigoDeBanco.size = 100;
                codigoDeBanco.scale = 0;
                codigoDeBanco.parameterDirection = ParameterDirection.Output;
                codigoDeBanco.value = "";
                AddParameter(codigoDeBanco);

                var tipoDeCuenta = new EasyParameter();
                tipoDeCuenta.field = "tipoDeCuenta";
                tipoDeCuenta.type = OleDbType.VarChar;
                tipoDeCuenta.size = 100;
                tipoDeCuenta.scale = 0;
                tipoDeCuenta.parameterDirection = ParameterDirection.Output;
                tipoDeCuenta.value = "";
                AddParameter(tipoDeCuenta);

                var codigoDeRuta = new EasyParameter();
                codigoDeRuta.field = "codigoDeRuta";
                codigoDeRuta.type = OleDbType.VarChar;
                codigoDeRuta.size = 100;
                codigoDeRuta.scale = 0;
                codigoDeRuta.parameterDirection = ParameterDirection.Output;
                codigoDeRuta.value = "";
                AddParameter(codigoDeRuta);

                var numeroDeCuenta = new EasyParameter();
                numeroDeCuenta.field = "numeroDeCuenta";
                numeroDeCuenta.type = OleDbType.VarChar;
                numeroDeCuenta.size = 100;
                numeroDeCuenta.scale = 0;
                numeroDeCuenta.parameterDirection = ParameterDirection.Output;
                numeroDeCuenta.value = "";
                AddParameter(numeroDeCuenta);

                var tipoDeIdentificacionCuenta = new EasyParameter();
                tipoDeIdentificacionCuenta.field = "tipoDeIdentificacionCuenta";
                tipoDeIdentificacionCuenta.type = OleDbType.VarChar;
                tipoDeIdentificacionCuenta.size = 100;
                tipoDeIdentificacionCuenta.scale = 0;
                tipoDeIdentificacionCuenta.parameterDirection = ParameterDirection.Output;
                tipoDeIdentificacionCuenta.value = "";
                AddParameter(tipoDeIdentificacionCuenta);

                var numeroDeIdentificacionCuenta = new EasyParameter();
                numeroDeIdentificacionCuenta.field = "numeroDeIdentificacionCuenta";
                numeroDeIdentificacionCuenta.type = OleDbType.VarChar;
                numeroDeIdentificacionCuenta.size = 100;
                numeroDeIdentificacionCuenta.scale = 0;
                numeroDeIdentificacionCuenta.parameterDirection = ParameterDirection.Output;
                numeroDeIdentificacionCuenta.value = "";
                AddParameter(numeroDeIdentificacionCuenta);

                var nombreCliente = new EasyParameter();
                nombreCliente.field = "nombreCliente";
                nombreCliente.type = OleDbType.VarChar;
                nombreCliente.size = 100;
                nombreCliente.scale = 0;
                nombreCliente.parameterDirection = ParameterDirection.Output;
                nombreCliente.value = "";
                AddParameter(nombreCliente);

                var alias = new EasyParameter();
                alias.field = "alias";
                alias.type = OleDbType.VarChar;
                alias.size = 100;
                alias.scale = 0;
                alias.parameterDirection = ParameterDirection.Output;
                alias.value = "";
                AddParameter(alias);

                var codMoneda = new EasyParameter();
                codMoneda.field = "codMoneda";
                codMoneda.type = OleDbType.VarChar;
                codMoneda.size = 100;
                codMoneda.scale = 0;
                codMoneda.parameterDirection = ParameterDirection.InputOutput;
                codMoneda.value = "";
                AddParameter(codMoneda);

                var valBancoDestino = new EasyParameter();
                valBancoDestino.field = "valBancoDestino";
                valBancoDestino.type = OleDbType.VarChar;
                valBancoDestino.size = 100;
                valBancoDestino.scale = 0;
                valBancoDestino.parameterDirection = ParameterDirection.Output;
                valBancoDestino.value = "";
                AddParameter(valBancoDestino);

                var descripcion = new EasyParameter();
                descripcion.field = "descripcion";
                descripcion.type = OleDbType.VarChar;
                descripcion.size = 100;
                descripcion.scale = 0;
                descripcion.parameterDirection = ParameterDirection.Output;
                descripcion.value = "";
                AddParameter(descripcion);

                var estado = new EasyParameter();
                estado.field = "estado";
                estado.type = OleDbType.VarChar;
                estado.size = 100;
                estado.scale = 0;
                estado.parameterDirection = ParameterDirection.Output;
                estado.value = "";
                AddParameter(estado);

                var codigoRechazo = new EasyParameter();
                codigoRechazo.field = "codigoRechazo";
                codigoRechazo.type = OleDbType.VarChar;
                codigoRechazo.size = 100;
                codigoRechazo.scale = 0;
                codigoRechazo.parameterDirection = ParameterDirection.Output;
                codigoRechazo.value = "";
                AddParameter(codigoRechazo);

                var valBanco = new EasyParameter();
                valBanco.field = "valBanco";
                valBanco.type = OleDbType.VarChar;
                valBanco.size = 100;
                valBanco.scale = 0;
                valBanco.parameterDirection = ParameterDirection.Output;
                valBanco.value = "";
                AddParameter(valBanco);

                var codTipoTransaccion = new EasyParameter();
                codTipoTransaccion.field = "codTipoTransaccion";
                codTipoTransaccion.type = OleDbType.VarChar;
                codTipoTransaccion.size = 100;
                codTipoTransaccion.scale = 0;
                codTipoTransaccion.parameterDirection = ParameterDirection.InputOutput;
                codTipoTransaccion.value = "";
                AddParameter(codTipoTransaccion);

                var valFechaHoraCreacion = new EasyParameter();
                valFechaHoraCreacion.field = "valFechaHoraCreacion";
                valFechaHoraCreacion.type = OleDbType.VarChar;
                valFechaHoraCreacion.size = 100;
                valFechaHoraCreacion.scale = 0;
                valFechaHoraCreacion.parameterDirection = ParameterDirection.Output;
                valFechaHoraCreacion.value = "";
                AddParameter(valFechaHoraCreacion);

                var valCuentaOrigen = new EasyParameter();
                valCuentaOrigen.field = "valCuentaOrigen";
                valCuentaOrigen.type = OleDbType.VarChar;
                valCuentaOrigen.size = 100;
                valCuentaOrigen.scale = 0;
                valCuentaOrigen.parameterDirection = ParameterDirection.Output;
                valCuentaOrigen.value = "";
                AddParameter(valCuentaOrigen);

        }   
    }
 }   

