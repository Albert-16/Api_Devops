using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data;
using System.Data.OleDb;

namespace Domain.Entities
{
    public class CYBI0060CL : EasyMappingTool
    {
        public CYBI0060CL()
        {
            SetClProgram("CYBERPGM", "CYBI0060CL");

            EasyParameter valCuentaOrigen = new EasyParameter
            {
                field = "valCuentaOrigen",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valCuentaOrigen);

            EasyParameter valCuentaDestino = new EasyParameter
            {
                field = "valCuentaDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(valCuentaDestino);

            EasyParameter codTipoCuentaDestino = new EasyParameter
            {
                field = "codTipoCuentaDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(codTipoCuentaDestino);

            EasyParameter familia = new EasyParameter
            {
                field = "familia",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(familia);

            EasyParameter tipoProducto = new EasyParameter
            {
                field = "tipoProducto",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(tipoProducto);

            EasyParameter grupoProducto = new EasyParameter
            {
                field = "grupoProducto",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(grupoProducto);

            EasyParameter codigoProducto = new EasyParameter
            {
                field = "codigoProducto",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(codigoProducto);

            EasyParameter monedaOrigen = new EasyParameter
            {
                field = "monedaOrigen",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(monedaOrigen);

            EasyParameter tipoCtaDestino = new EasyParameter
            {
                field = "tipoCtaDestino",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(tipoCtaDestino);

            EasyParameter tipoCtaOrigen = new EasyParameter
            {
                field = "tipoCtaOrigen",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(tipoCtaOrigen);

        }
    }
}
