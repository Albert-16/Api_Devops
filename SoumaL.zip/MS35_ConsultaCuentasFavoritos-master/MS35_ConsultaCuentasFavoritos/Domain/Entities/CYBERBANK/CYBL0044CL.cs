using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data;
using System.Data.OleDb;

namespace Domain.Entities.CYBERPGM
{
    public class CYBL0044CL : EasyMappingTool
    {
        public CYBL0044CL()
        {
            SetClProgram("CYBERPGM", "CYBL0044CL");
            EasyParameter numeroDeCuenta = new EasyParameter
            {
                field = "numeroDeCuenta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(numeroDeCuenta);

            EasyParameter correlativoCta = new EasyParameter
            {
                field = "correlativoCta",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(correlativoCta);

            EasyParameter correlativoEmail = new EasyParameter
            {
                field = "correlativoEmail",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Input,
                value = ""
            };
            AddParameter(correlativoEmail);

            EasyParameter valEmail = new EasyParameter
            {
                field = "valEmail",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(valEmail);


        }
    }
}
