using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data;
using System.Data.OleDb;

namespace Domain.Entities.CYBERBANK
{
    public class EmailsCL : EasyMappingTool
    {
        public EmailsCL()
        {
            EasyParameter valEmail = new EasyParameter
            {
                field = "valEmail",
                type = OleDbType.VarChar,
                size = 100,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(valEmail);
        }
    }
}
