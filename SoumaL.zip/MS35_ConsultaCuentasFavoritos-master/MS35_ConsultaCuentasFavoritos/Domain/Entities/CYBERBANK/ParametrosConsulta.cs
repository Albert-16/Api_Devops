﻿using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data.OleDb;

namespace Domain.Entities.CYBERBANK
{
    public static class ParametrosConsulta
    {
        public static EasyParameter Parametros(string Field, string Value, int Size, OleDbType Type)
        {

            EasyParameter field = new EasyParameter
            {
                field = Field,
                size = Size,
                scale = 0,
                type = Type,
                value = Value,
                parameterDirection = System.Data.ParameterDirection.InputOutput
            };
            return field;

        }
    }
}
