﻿using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System.Data;
using System.Data.OleDb;

namespace Domain.Entities.CYBERBANK
{
    public class PropiedadesAdicionalesCL : EasyMappingTool
    {
        public PropiedadesAdicionalesCL()
        {

            EasyParameter valNombre = new EasyParameter
            {
                field = "valNombre",
                type = OleDbType.VarChar,
                size = 64,
                scale = 0,
                parameterDirection = ParameterDirection.InputOutput,
                value = ""
            };
            AddParameter(valNombre);

            EasyParameter valValor = new EasyParameter
            {
                field = "valValor",
                type = OleDbType.VarChar,
                size = 10,
                scale = 0,
                parameterDirection = ParameterDirection.Output,
                value = ""
            };
            AddParameter(valValor);
        }
    }
}

