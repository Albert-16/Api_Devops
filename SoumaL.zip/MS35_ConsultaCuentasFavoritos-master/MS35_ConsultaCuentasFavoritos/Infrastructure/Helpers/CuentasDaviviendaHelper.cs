﻿using EasyTemplateSolution.Domain.Dto;
using System.Collections.Generic;
using System.Data.OleDb;

namespace Infrastructure.Helpers
{
    public class CuentasDaviviendaHelper
    {
        private readonly OleDbConnection _oleDbConnection;

        public CuentasDaviviendaHelper(OleDbConnection oleDbConnection)
        {
            _oleDbConnection = oleDbConnection;
        }


        public void CuentaDavivienda(Data response)
        {
            Data cuentasDavivi = new Data
            {
                Field = "Registros",
                DataList = new List<Data>()
            };

            foreach (Data item in response.DataList)
            {
                foreach (Data registro in item.DataList)
                {
                    if (registro.Value.Equals("D"))
                    {

                        cuentasDavivi.DataList.Add(item);
                        break;
                    }
                }
            }
        }

    }
}
