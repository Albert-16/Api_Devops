﻿using EasyTemplateSolution.Domain.Dto;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Helpers
{
    public static class DataAdicionalResponse
    {
        public static string DatosAdicionales(Data registro, string campo)
        {

            string value = (from valor in registro.DataList
                            where valor.Field == campo
                            select valor.Value).FirstOrDefault().ToString();
            return value;
        }
        public static void Adicionar(Data registro, Data propiedadesAdicionales)
        {
            Data response = new Data
            {
                Field = "PropiedadAdicional",
                HasData = true,
                DataList = new List<Data>()
            };

            string value = (from item in registro.DataList
                            where item.Field == "tipoCtaDestino"
                            select item.Value).FirstOrDefault().ToString();

            if (value != null)
            {
                Data valNombre = new Data
                {
                    Field = "valNombre",
                    HasData = true,
                    Value = "tipoProductoDestino"
                };

                Data valValor = new Data
                {
                    Field = "valValor",
                    HasData = true
                };

                valValor.Value = value.Equals("") ? "0" : value;

                response.DataList.Add(valNombre);
                response.DataList.Add(valValor);
            }

            propiedadesAdicionales.DataList.Add(response);
        }
    }
}
