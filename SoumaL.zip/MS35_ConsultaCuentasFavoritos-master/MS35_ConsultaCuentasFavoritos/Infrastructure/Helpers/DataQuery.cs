﻿using Domain.Entities;
using Domain.Entities.CYBERBANK;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using SUNITP.LIB.QueryStringGenerator;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;

namespace Infrastructure.Helpers
{
    public class DataQuery
    {
        private readonly OleDbConnection _oleDbConnection;
        private readonly ISunitpService _sunitpService;
        private string _tipTransf;
        private string _tipTrans;
        private string _nIdentificacion;
        private string _nCuenta;
        private string _nCtaDestino;
        private string _nombreTitular;
        private string _valAlias;
        private string _ideDesti;
        private EasyParameter _titular;
        private EasyParameter _alias;
        private EasyParameter _numeroIdentificacion;
        private EasyParameter _ctaDestino;
        private EasyParameter _numeroCuenta;
        private EasyParameter _tipoTransaccion;
        private EasyParameter _tipoTransferencia;
        private EasyParameter _ideDestino;


        public DataQuery(ISunitpService sunitpService, OleDbConnection oleDbConnection)
        {
            _oleDbConnection = oleDbConnection;
            _sunitpService = sunitpService;
        }

        public void LoadData(CYB00035CL cyb00035cl)
        {
            _tipTransf = cyb00035cl.GetValue("codTipoCuentaDestino").TrimStart().TrimEnd();
            _tipTrans = cyb00035cl.GetValue("codTipoTransa1r21ccion").TrimStart().TrimEnd();
            _nIdentificacion = cyb00035cl.GetValue("numeroIdentificacion").TrimStart().TrimEnd();
            _nCuenta = cyb00035cl.GetValue("cuentaACH").TrimStart().TrimEnd();
            _nCtaDestino = cyb00035cl.GetValue("valCuentaDestino").TrimStart().TrimEnd();
            _nombreTitular = cyb00035cl.GetValue("valNombreTitular").TrimStart().TrimEnd();
            _valAlias = cyb00035cl.GetValue("valAlias").TrimStart().TrimEnd();
            _ideDesti = cyb00035cl.GetValue("valNumeroIdentificacionDestino").TrimStart().TrimEnd();
        }

        public Data GetCuentas(CYB00035CL cyb00035cl)
        {
            string signoAlias = "LIKE ";
            string signoCuentasDestino = "LIKE";
            string signoNombreTitular = "LIKE ";
            string signoIdentificacion = "LIKE ";
            string signonumeroIdentificacion = "=";
            string signonumIdentDest = "LIKE ";
            string signoTipoTransaccion = "LIKE ";

            _titular = new EasyParameter();
            _alias = new EasyParameter();
            _numeroIdentificacion = new EasyParameter();
            _ctaDestino = new EasyParameter();
            _numeroCuenta = new EasyParameter();
            _tipoTransaccion = new EasyParameter();
            _tipoTransferencia = new EasyParameter();
            _ideDestino = new EasyParameter();

            bool isTrxDestino = ValidarTipoTrxDestino(cyb00035cl);

            if (isTrxDestino)
            {
                _titular = ParametrosConsulta.Parametros("NOMTI2)", $"{_nombreTitular}", 100, OleDbType.VarChar);
                _alias = ParametrosConsulta.Parametros("VALALIA2)", $"%{_valAlias}%", 100, OleDbType.VarChar);
                _numeroIdentificacion = ParametrosConsulta.Parametros("NUMIDE2", _nIdentificacion, 100, OleDbType.VarChar);
                _ctaDestino = ParametrosConsulta.Parametros("NUMCTAE2", $"%{_nCtaDestino}%", 100, OleDbType.VarChar);
                _numeroCuenta = ParametrosConsulta.Parametros("NUMCTA2", $"%{_nCuenta}%", 100, OleDbType.VarChar);
                _ideDestino = ParametrosConsulta.Parametros("NUMIDEE2", $"%{_ideDesti}%", 100, OleDbType.VarChar);
            }
            else
            {
                _titular = ParametrosConsulta.Parametros("NOMTIT", $"%{_nombreTitular}%", 100, OleDbType.VarChar);
                _alias = ParametrosConsulta.Parametros("VALALIAS", $"%{_valAlias}%", 100, OleDbType.VarChar);
                _numeroIdentificacion = ParametrosConsulta.Parametros("NUMIDEO", $"{_nIdentificacion}", 100, OleDbType.VarChar);
                _ctaDestino = ParametrosConsulta.Parametros("NUMCTAD", $"%{_nCtaDestino}%", 100, OleDbType.VarChar);
                _numeroCuenta = ParametrosConsulta.Parametros("NUMCTAO", $"%{_nCuenta}%", 100, OleDbType.VarChar);
                _tipoTransaccion = ParametrosConsulta.Parametros("CODTIPTRN", $"%{_tipTransf}%", 100, OleDbType.VarChar);
                _ideDestino = ParametrosConsulta.Parametros("NUMIDED", $"%{_ideDesti}%", 100, OleDbType.VarChar);
            }

            Data listEmail = new Data();
            EasyParameter vaEstado1 = ParametrosConsulta.Parametros("VALEST", "5", 100, OleDbType.VarChar);

            //Evaluacion para signos de consulta
            if (_numeroIdentificacion.value.Equals("%%"))
            {
                signonumeroIdentificacion = "<>";
                _numeroIdentificacion.value = "0";
            }
            if (_ideDestino.value.Equals("%%"))
            {
                signonumIdentDest = "<>";
                _ideDestino.value = "0";
            }
            if (_alias.value.Equals("%%"))
            {
                signoAlias = "<>";
                _alias.value = "0";
            }
            if (_titular.value.Equals("%%"))
            {
                signoNombreTitular = "<>";
                _titular.value = "0";
            }
            if (_ctaDestino.value.Equals("%%"))
            {
                signoCuentasDestino = "<>";
                _ctaDestino.value = "0";
            }
            if (_numeroCuenta.value.Equals("%%"))
            {
                signoIdentificacion = "<>";
                _numeroCuenta.value = "0";
            }
            if (_tipoTransaccion.value.Equals("%%") || _tipoTransaccion.value.Equals("%T%"))
            {
                signoTipoTransaccion = "<>";
            }
            else if (_tipoTransaccion.value.Equals("%E%") || _tipoTransaccion.value.Equals("%I%"))
            {
                signoTipoTransaccion = "=";
                _tipoTransaccion.value = _tipoTransaccion.value.Replace("%", "");
            }

            string tabla = (isTrxDestino) ? "ICYBFVS" : "ICYBFAV";
            //int bandera = (cyb00035cl.GetValue("codTipoCuentaDestino").Equals("S") && cyb00035cl.GetValue("codTipoTransaccion").Equals("C")) ? 1 : 0;

            //Creacion de Consulta
            ServiceQueryStringGenerator sqsg = new ServiceQueryStringGenerator();
            sqsg._iQueryStringGenerator.SelectAll();
            sqsg._iQueryStringGenerator.From("CYBERDTA", tabla); //
            sqsg._iQueryStringGenerator.WhereAnd(_numeroIdentificacion, signonumeroIdentificacion);
            sqsg._iQueryStringGenerator.WhereAnd(_numeroCuenta, signoIdentificacion);
            sqsg._iQueryStringGenerator.WhereAnd(_ideDestino, signonumIdentDest);
            sqsg._iQueryStringGenerator.WhereAnd(_ctaDestino, signoCuentasDestino);
            sqsg._iQueryStringGenerator.WhereAnd(_titular, signoNombreTitular);
            sqsg._iQueryStringGenerator.WhereAnd(_alias, signoAlias);

            if (tabla.Equals("ICYBFAV"))
            {
                sqsg._iQueryStringGenerator.WhereAnd(_tipoTransaccion, signoTipoTransaccion);
                //filtro
                sqsg._iQueryStringGenerator.WhereOr(vaEstado1, "<>");
                sqsg._iQueryStringGenerator.OrderBy("NUMCTAO");
            }
            else
            {
                sqsg._iQueryStringGenerator.OrderBy("NUMCTA2");
            }

            var a = sqsg._iQueryStringGenerator.GetQueryStatement();
            var b = sqsg._iQueryStringGenerator.GetParameterCollection();
            _sunitpService.AddSingleLog(sqsg._iQueryStringGenerator.GetQueryStatement());
            _sunitpService.AddObjLog("ConsultaCuentasFavoritas GetListaCuentasFavoritas", "00000000000000000000", "PARAMETROS PARA EJECUTAR EL QUERY", sqsg._iQueryStringGenerator.GetParameterCollection());

            EasyCrudModels ecm = new EasyCrudModels(_oleDbConnection);
            List<EasyMappingTool> response = ecm.SelectExecute(sqsg);
            cyb00035cl.SetValue("cantidadRegistros", response.Count().ToString());

            Mapper nameTagMapper = new Mapper(_sunitpService, _oleDbConnection, cyb00035cl);

            //Validar registros devueltos por consulta
            if (!response.Count.Equals(0))
            {
                //Data tags = isTrxDestino
                //    ? nameTagMapper.MapData(response, TableDictionaries.CamposCuentasDavivienda(), "Registro", 0, 0);
                //    : nameTagMapper.MapData(response, TableDictionaries.CybFavDictionary(), "Registro", 0);
                //listEmail = new Parametrizacion(_oleDbConnection, _sunitpService).Email(tags, cyb00035cl);
            }
            else
            {
                cyb00035cl.SetValue("msgRespuesta", "CLIENTE NO TIENE CUENTAS INSCRITAS");
                cyb00035cl.SetValue("caracterAceptacion", "M");
                cyb00035cl.SetValue("codMsgRespuesta", "180305");
            }

            return listEmail;

        }
        private bool ValidarTipoTrxDestino(EasyMappingTool clProgram)
        {
            return clProgram.GetValue("codTipoCuentaDestino").Equals("S") && clProgram.GetValue("codTipoTransaccion").Equals("C");
        }

    }
}
