﻿using Domain.Entities;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using System.Data.OleDb;

namespace Infrastructure.Helpers
{
    public class ListaCuentasFavoritasHelper
    {
        private readonly OleDbConnection _oleDbConnection;
        private readonly ISunitpService _sunitpService;

        public ListaCuentasFavoritasHelper(ISunitpService sunitpService, OleDbConnection oleDbConnection)
        {
            _oleDbConnection = oleDbConnection;
            _sunitpService = sunitpService;
        }

        public Data Get(CYB00035CL cyb00035cl)
        {
            _sunitpService.AddSingleLog("ListaCuentasFavoritasHelper");
            //Data cuentasSinpe = new Data();

            //Data dataResponse = new Data
            //{
            //    Field = "Registros",
            //    DataList = new List<Data>()
            //};


            //recuperar datos de la CL
            CuentasSINPEHelper claseCtaSinpe = new CuentasSINPEHelper(_sunitpService, _oleDbConnection);
            claseCtaSinpe.LoadData(cyb00035cl);


            Data cuentaDavivi = claseCtaSinpe.GetCuentas(cyb00035cl);

            return cuentaDavivi;
        }
    }
}
