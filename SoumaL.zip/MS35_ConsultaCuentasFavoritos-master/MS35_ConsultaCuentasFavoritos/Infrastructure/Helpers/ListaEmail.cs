﻿using Domain.Entities.CYBERBANK;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using Infrastructure.Dictionaries;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.QueryStringGenerator;
using System.Collections.Generic;
using System.Data.OleDb;

namespace Infrastructure.Helpers
{
    public class ListaEmail
    {
        private readonly OleDbConnection _oleDbConnection;
        private ISunitpService _sunitpService;

        public ListaEmail(ISunitpService sunitpService, OleDbConnection oleDbConnection)
        {
            _oleDbConnection = oleDbConnection;
            _sunitpService = sunitpService;
        }

        public Data Email(Data response, string guid, string identidad)
        {
            // _sunitpService.AddSingleLog("ListaEmailCuentasFavoritasHelpers");
            Data tags = new Data();

            //Mapping de campos para consulta
            SUNITP.LIB.ManagerProcedures.Concrete.EasyParameter numeroIdent = ParametrosConsulta.Parametros("NUMIDEO", identidad.ToString(), 100, OleDbType.VarChar);
            SUNITP.LIB.ManagerProcedures.Concrete.EasyParameter guidId = ParametrosConsulta.Parametros("GUIDCOR", guid.ToString(), 100, OleDbType.VarChar);


            ServiceQueryStringGenerator sqsg = new ServiceQueryStringGenerator();
            sqsg._iQueryStringGenerator.SelectAll();
            sqsg._iQueryStringGenerator.From("CYBERDTA", "UCYBFAVC");
            sqsg._iQueryStringGenerator.WhereAnd(guidId, "=");
            sqsg._iQueryStringGenerator.WhereAnd(numeroIdent, "=");
            sqsg._iQueryStringGenerator.OrderBy("NUMIDEO");


            EasyCrudModels ecm = new EasyCrudModels(_oleDbConnection);
            List<EasyMappingTool> responseQuery = ecm.SelectExecute(sqsg);

            NombreTagHelper nameTagEmail = new NombreTagHelper(_sunitpService, _oleDbConnection);
            ValidarRegistrosConsultasHelper validate = new ValidarRegistrosConsultasHelper(_sunitpService);


            if (validate.ValidarRegistros(responseQuery))
            {
                tags = nameTagEmail.TagGetEmail(responseQuery, TableDictionaries.CybFavDictionary(), "Email");
            }

            if (tags.HasData.Equals(true))
            {
                foreach (Data emails in tags.DataList)
                {
                    foreach (Data email in emails.DataList)
                    {
                        if (email.HasData.Equals(true))
                        {
                            response.DataList.Add(tags);
                        }
                    }
                }
            }

            return response;
        }
    }

}

