﻿using Domain.Entities;
using Domain.Entities.CYBERBANK;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using Infrastructure.Dictionaries;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using SUNITP.LIB.QueryStringGenerator;
using System.Collections.Generic;
using System.Data.OleDb;

namespace Infrastructure.Helpers
{
    public class ListaEmailCuentasFavoritasHelpers
    {
        private readonly OleDbConnection _oleDbConnection;

        public ListaEmailCuentasFavoritasHelpers(OleDbConnection oleDbConnection)
        {
            _oleDbConnection = oleDbConnection;
        }

        public Data Email(Data response, ISunitpService _sunitpService, CYB00035CL cyb00035cl)
        {
            // _sunitpService.AddSingleLog("ListaEmailCuentasFavoritasHelpers");
            Dictionary<string, string> diccioary = TableDictionaries.ValidateFieldsOnlyFav();
            Data tags = new Data();
            string guid = "";


            //int bandera = (!cyb00035cl.GetValue("codTipoTransaccion").Equals("S")) ? 0 : 1;

            foreach (Data item in response.DataList)
            {
                foreach (Data registro in item.DataList)
                {
                    if (registro.Field.Equals("guid"))
                    {
                        guid = registro.Value;
                    }
                }


                string numIdent = cyb00035cl.GetValue("numeroIdentificacion");


                //Mapping de campos para consulta
                EasyParameter numeroIdent = ParametrosConsulta.Parametros("NUMIDEO", numIdent.ToString(), 100, OleDbType.VarChar);
                EasyParameter guidId = ParametrosConsulta.Parametros("GUIDCOR", guid.ToString(), 100, OleDbType.VarChar);


                ServiceQueryStringGenerator sqsg = new ServiceQueryStringGenerator();
                sqsg._iQueryStringGenerator.SelectAll();
                sqsg._iQueryStringGenerator.From("CYBERDTA", "UCYBFAVC");
                sqsg._iQueryStringGenerator.WhereAnd(guidId, "=");
                sqsg._iQueryStringGenerator.WhereAnd(numeroIdent, "=");
                sqsg._iQueryStringGenerator.OrderBy("NUMIDEO");


                EasyCrudModels ecm = new EasyCrudModels(_oleDbConnection);
                List<EasyMappingTool> responseQuery = ecm.SelectExecute(sqsg);

                NombreTagHelper nameTagEmail = new NombreTagHelper(_sunitpService, _oleDbConnection);
                NombreTagHelper nameTag = new NombreTagHelper(_sunitpService, _oleDbConnection);
                ValidarRegistrosConsultasHelper validate = new ValidarRegistrosConsultasHelper(_sunitpService);


                if (validate.ValidarRegistros(responseQuery))
                {
                    tags = nameTagEmail.TagGetEmail(responseQuery, diccioary, "Email");
                }


                if (tags.HasData.Equals(true))
                {
                    foreach (Data emails in tags.DataList)
                    {
                        foreach (Data email in emails.DataList)
                        {
                            if (email.HasData.Equals(true))
                            {
                                item.DataList.Add(tags);
                            }
                        }
                    }
                }
            }

            return response;
        }
    }
}
