﻿using Domain.Entities;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using EasyTemplateSolution.Infrastructure.Repository;
using SUNITP.LIB.ManagerProcedures;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics;

namespace Infrastructure.Helpers
{
    public class LlamadaCoreHelper
    {
        private readonly OleDbConnection _oleDbConnection;
        private readonly ISunitpService _sunitpService;
        public LlamadaCoreHelper(ISunitpService sunitpService, OleDbConnection oleDbConnection)
        {
            _oleDbConnection = oleDbConnection;
            _sunitpService = sunitpService;
        }

        public Data Call(Data dataResponse, CYB00035CL cyb00035cl)
        {
            _sunitpService.AddSingleLog("LlamadoCoreHelper");
            Data listaCuentasFavoritas = new Data();


            Data registros = new Data
            {
                Field = "Registros",
                DataList = new List<Data>()
            };

            Stopwatch timeMeasure = new Stopwatch();
            timeMeasure.Start();


            //CallModel
            EasyDataModels edm = new EasyDataModels();
            edm.EasyCallInit(_oleDbConnection, cyb00035cl);
            edm.CallProcedure();
            _sunitpService.AddObjLog("ConsultaCunetasFavoritas DoProcess", "00000000000000000000", "OBJETO RECIBIDO", cyb00035cl.GetObject());


            if (edm.IsSuccessful())
            {
                ResponseDataMapper rdm = new ResponseDataMapper("", "RESPONSE", "", "00000000000000000000", "PROCESO REALIZADO EXITOSAMENTE", "");

                string caracterAceptacion = cyb00035cl.GetValue("caracterAceptacion");
                cyb00035cl.SetValue("archivoContinuacion", "0");
                cyb00035cl.SetValue("valTalonRegistroAnterior", "0");

                if (caracterAceptacion.Equals("B"))
                {

                    DataQuery dataQuery = new DataQuery(_sunitpService, _oleDbConnection);
                    dataQuery.LoadData(cyb00035cl);
                    listaCuentasFavoritas = dataQuery.GetCuentas(cyb00035cl); //to-do Jose Leon tratar de averiguar si esta consulta se puede eliminar o unificar en el llamado del core.

                    dataResponse = rdm.Map(cyb00035cl);
                    dataResponse.DataList.Add(listaCuentasFavoritas);
                }
                else
                {
                    dataResponse = rdm.Map(cyb00035cl);
                }
            }
            else
            {
                dataResponse.Error = "10000000000000000005";
                dataResponse.ExternalError = "ERROR AL MOMENTO DE LLAMAR AL PROCEDIMIENTO ALMACENADO";
                dataResponse.InternalError = cyb00035cl.GetValue("_defaultError");
            }

            return dataResponse;
        }

        internal Data Call(Data dataresponse, EasyMappingTool cyb00035cl)
        {
            throw new NotImplementedException();
        }
    }
}
