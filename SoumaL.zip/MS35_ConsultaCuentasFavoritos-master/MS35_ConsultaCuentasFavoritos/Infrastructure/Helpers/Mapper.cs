﻿using Domain.Entities;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.Repository;
using Infrastructure.Utilities;
using Infrastructure.Utillities;
using SUNITP.LIB.ManagerProcedures;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;

namespace Infrastructure.Helpers
{
    public class Mapper
    {
        private readonly OleDbConnection _oleDbConnection;
        private readonly ISunitpService _sunitpService;
        private EasyMappingTool _clProgram;

        public Mapper(ISunitpService sunitpService, OleDbConnection oleDbConnection, EasyMappingTool clProgram)
        {
            _oleDbConnection = new OleDbConnection();
            _oleDbConnection = oleDbConnection;
            _sunitpService = sunitpService;
            _clProgram = clProgram;
        }

        public Mapper()
        {

        }

        //public Data MapData(List<EasyMappingTool> response, Dictionary<string, string> diccionary, string nombre, int contador, int t, string codTipoCuentaDestino, ref int cant)
        public Data MapData(List<EasyMappingTool> response, Dictionary<string, string> diccionary, string nombre, int contador, int t, string codTipoCuentaDestino, ref int cant, List<EasyMappingTool> CorreoRes)
        {
            int contaFinal = contador + 250;
            var index = 0;

            Data lista = new Data
            {
                HasData = true,
                Field = $"{nombre}s",
                Id = index.ToString(),
                DataList = new List<Data>()
            };

            var bandera = 0;
            string estado = "";

            var fQuery = new FieldsQuery();
            foreach (EasyMappingTool item in response)
            {
                var temp = CorreoRes;
                var gid1= item.GetValue("GUIDCTFV").ToString();
                //Valida que la cuenta se de 10 digitos si no los rellena con 0
                /*var cuenta = item.GetValue("NUMCTAO").ToString();
                if (cuenta.Length < 10)
                {
                    cuenta = cuenta.PadLeft(10, '0');
                    item.SetValue("NUMCTAO", cuenta);
                }*/
                if (codTipoCuentaDestino == "T" || (codTipoCuentaDestino == item.GetValue("CODTIPTRN")))
                {

                    index++;

                    if (index >= contador && index <= contaFinal)
                    {

                       

                        Data registro = new Data
                        {
                            HasData = true,
                            Field = nombre,
                            Id = index.ToString(),
                            DataList = new List<Data>()
                        };


                        //ResponseDataMapper responseDataMapper = new ResponseDataMapper("", "", "", "", "", "");
                        
                        registro.DataList.Add(CrearParametros.GetData("codigoDeBanco", item.GetValue("CODBCO").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("numeroDeCuenta", item.GetValue("NUMCTAD").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("valBancoDestino", item.GetValue("BCODES").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("descripcion", item.GetValue("VALEST").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("valFechaHoraCreacion", item.GetValue("FCHFAVCR").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("codMoneda", item.GetValue("CODMOND").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("alias", item.GetValue("VALALIAS").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("nombreCliente", item.GetValue("NOMTIT").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("numeroDeIdentificacionCuenta", item.GetValue("NUMIDED").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("valCuentaOrigen", item.GetValue("NUMCTAO").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("codTipoTransaccion", item.GetValue("CODTIPTRN").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("guid", item.GetValue("GUIDCTFV").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("tipoCtaDestino", item.GetValue("TIPCTAFD").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("tipoCtaOrigen", item.GetValue("TIPCTAFO").Trim(), true));
                        registro.DataList.Add(CrearParametros.GetData("monedaOrigen", item.GetValue("CODMONO").Trim(), true));
                        


                        var cybi0060cl = new CYBI0060CL();
                        /*foreach (string key in diccionary.Keys)
                        {
                            string value = item.GetValue(key);
                            string field = diccionary[key];
                            Data itemData = new Data()
                            {
                                HasData = value != "" ? true : false,
                                Field = field,
                                Value = value
                            };
                            


                            switch (field)
                            {
                                case "tipoCtaDestino":
                                    cybi0060cl.SetValue("codTipoCuentaDestino", value);
                                    break;
                                case "codTipoTransaccion":
                                    cybi0060cl.SetValue("tipoCtaDestino", value);
                                    break;
                                case "monedaOrigen":
                                    cybi0060cl.SetValue("monedaOrigen", value);
                                    break;

                                case "tipoProductoDestino":
                                    cybi0060cl.SetValue("tipoProductoDestino", value);
                                    break;
                                case "valCuentaOrigen":
                                    cybi0060cl.SetValue("valCuentaOrigen", value);
                                    break;
                                case "tipoCtaOrigen":
                                    cybi0060cl.SetValue("tipoCtaOrigen", value);
                                    break;
                            }
                            registro.DataList.Add(itemData);
                        }*/
                        //correos
                        temp = (from item1 in temp
                                where item1.GetValue("GUIDCOR") == gid1
                                select item1).ToList();

                        Data Emails = new Data()
                        {
                            HasData = true,
                            Field = "Emails",
                            DataList = new List<Data>()
                        };
                        
                        foreach (EasyMappingTool cor in temp)
                        {
                            Data Email = new Data()
                            {
                                HasData = true,
                                Field = "Email",
                                DataList = new List<Data>()
                            };

                            Data valEmail = new Data()
                            {
                                HasData = true,
                                Field = "valEmail",
                                Value = cor.GetValue("FAVMAIL").ToString()
                            };
                            Email.DataList.Add(valEmail);
                            Emails.DataList.Add(Email);
                        }
                        
                        registro.DataList.Add(Emails); 
                        /*if (diccionary.Count > 1)
                        {
                            DataMissing(registro, true);
                        }*/
                        PropiedadesAdicionales props = new PropiedadesAdicionales(cybi0060cl);
                        registro.DataList.Add(props.GetProps2(item));
                        lista.DataList.Add(registro);
                    }
                }
            }
            cant = index;
            return lista;

        }
        public Data TagGetEmail(List<EasyMappingTool> response, Dictionary<string, string> dictionary, string nombre)
        {
            int i = 0;

            Data lista = new Data
            {
                HasData = true,
                Field = nombre + "s",
                Id = i.ToString(),
                DataList = new List<Data>()
            };

            foreach (EasyMappingTool item in response)
            {
                i++;
                Data registro = new Data
                {
                    HasData = true,
                    Field = nombre,
                    Id = i.ToString(),
                    DataList = new List<Data>()
                };

                ResponseDataMapper responseDataMapper = new ResponseDataMapper("", "", "", "", "", "");

                foreach (string key in dictionary.Keys)
                {
                    Data itemVal = new Data()
                    {
                        HasData = true,
                        Field = dictionary[key],
                        Value = item.GetValue(key)
                    };
                    registro.DataList.Add(itemVal);
                }

                lista.DataList.Add(registro);
            }
            return lista;
        }

        //funcion para devolver tags en duro que no esta en la tabla CYBCTFA de la CYBERPGM
        public void DataMissing(Data registro, bool bandera)
        {
            Data codigoDeRuta = new Data
            {
                Field = "codigoDeRuta",
                Value = "0"
            };

            if (bandera.Equals(0))
            {
                Data estado = new Data
                {
                    Field = "estado",
                    Value = "0"
                };

                registro.DataList.Add(estado);
            }

            Data codigoRechazo = new Data
            {
                Field = "codigoRechazo",
                Value = "0"
            };

            Data valBanco = new Data
            {
                Field = "valBanco",
                Value = "0"
            };

            registro.DataList.Add(codigoDeRuta);
            registro.DataList.Add(codigoRechazo);
            registro.DataList.Add(valBanco);
        }
    }
}
