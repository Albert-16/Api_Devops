﻿using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.Repository;
using SUNITP.LIB.ManagerProcedures;
using System;
using System.Collections.Generic;

namespace Infrastructure.Helpers
{
    public class NombreTagEmail
    {

        public NombreTagEmail() { }

        public Data TagGet(List<EasyMappingTool> response, Dictionary<string, string> dictionary, String nombre)
        {
            int i = 0;

            Data lista = new Data
            {
                HasData = true,
                Field = nombre + "s",
                Id = i.ToString(),
                DataList = new List<Data>()
            };

            foreach (EasyMappingTool item in response)
            {
                i++;
                Data registro = new Data
                {
                    HasData = true,
                    Field = nombre,
                    Id = i.ToString(),
                    DataList = new List<Data>()
                };

                ResponseDataMapper responseDataMapper = new ResponseDataMapper("", "", "", "", "", "");

                foreach (string key in dictionary.Keys)
                {
                    Data itemVal = new Data()
                    {
                        HasData = true,
                        Field = dictionary[key],
                        Value = item.GetValue(key)
                    };
                    registro.DataList.Add(itemVal);
                }

                lista.DataList.Add(registro);
            }
            return lista;
        }
    }
}
