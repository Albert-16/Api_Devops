﻿using Domain.Entities.CYBERBANK;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using EasyTemplateSolution.Infrastructure.Repository;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using SUNITP.LIB.QueryStringGenerator;
using System.Collections.Generic;
using System.Data.OleDb;

namespace Infrastructure.Helpers
{
    public class Parametrizacion
    {
        private readonly OleDbConnection _oleDbConnection;
        private readonly ISunitpService _sunitpService;

        public Parametrizacion(OleDbConnection oleDbConnection, ISunitpService sunitpService)
        {
            _oleDbConnection = oleDbConnection;
            _sunitpService = sunitpService;
        }

        public Data Email(Data response, EasyMappingTool cyb00035cl)
        {
            // _sunitpService.AddSingleLog("ListaEmailCuentasFavoritasHelpers");
            Data tags = new Data();


            bool bandera = (!cyb00035cl.GetValue("codTipoTransaccion").Equals("S")) ? false : true;
            string identidad = cyb00035cl.GetValue("numeroIdentificacion");


            //Mapping de campos para consulta
            EasyParameter numeroIdent = ParametrosConsulta.Parametros("NUMIDEO", identidad.ToString(), 100, OleDbType.VarChar);
            //var guidId = parametro.Parametros("GUIDCOR", guid.ToString(), 100, OleDbType.VarChar);


            ServiceQueryStringGenerator sqsg = new ServiceQueryStringGenerator();
            sqsg._iQueryStringGenerator.SelectAll();
            sqsg._iQueryStringGenerator.From("CYBERDTA", "UCYBFAVC");
            //sqsg._iQueryStringGenerator.WhereAnd(guidId, "=");
            sqsg._iQueryStringGenerator.WhereAnd(numeroIdent, "=");
            sqsg._iQueryStringGenerator.OrderBy("GUIDCOR");


            EasyCrudModels ecm = new EasyCrudModels(_oleDbConnection);
            List<EasyMappingTool> responseQuery = ecm.SelectExecute(sqsg);

            //Mapper nameTagEmail = new Mapper(_sunitpService, _oleDbConnection);
            //Mapper nameTag = new Mapper(_sunitpService, _oleDbConnection);
            ValidarRegistrosConsultasHelper validate = new ValidarRegistrosConsultasHelper(_sunitpService);


            if (validate.ValidarRegistros(responseQuery))
            {
                //tags = nameTagEmail.TagGetEmail(responseQuery, TableDictionaries.ValidateFieldsFav(), "Email");
            }


            EmailsCL emailsAdaptador = new EmailsCL();

            foreach (Data item in response.DataList)
            {

                Data datos = new Data
                {
                    HasData = true,
                    Field = "Emails",
                    DataList = new List<Data>()
                };

                foreach (Data item3 in item.DataList)
                {
                    string guid = "";
                    if (item3.Field.Equals("guid"))
                    {
                        guid = item3.Value;

                        foreach (Data item2 in tags.DataList)
                        {
                            foreach (Data item4 in item2.DataList)
                            {
                                if (item4.Value.Equals(guid))
                                {
                                    RequestObjectMapper rom = new RequestObjectMapper();
                                    rom.Map(emailsAdaptador, item2);

                                    ResponseDataMapper rdm = new ResponseDataMapper("", "Email", "", "", "", "");

                                    Data dato = rdm.Map(emailsAdaptador);

                                    datos.DataList.Add(dato);
                                }

                            }
                        }

                    }
                }
                item.DataList.Add(datos);
            }

            //if (tags.HasData.Equals(true))
            //{
            //    foreach (var emails in tags.DataList)
            //    {
            //        foreach (var email in emails.DataList)
            //        {
            //            if (email.HasData.Equals(true))
            //            {
            //                response.DataList.Add(tags);
            //            }
            //        }
            //    }
            //}


            return response;
        }
    }
}
