﻿using EasyTemplateSolution.Domain.Dto;
using SUNITP.LIB.ManagerProcedures;
using System.Collections.Generic;

namespace Infrastructure.Helpers
{
    public class PropiedadesAdicionales
    {
        public List<string> _values;
        public EasyMappingTool _cybi0060cl;
        public PropiedadesAdicionales(EasyMappingTool cybi0060cl)
        {
            this._cybi0060cl = cybi0060cl;
        }

        public Data GetProps()
        {
            //Familia, Tipo de producto, grupo, codigo
            var codTipoCuentaDestino = _cybi0060cl.GetValue("codTipoCuentaDestino");

            Data Props = new Data()
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };
            var valCuentaOrigen = _cybi0060cl.GetValue("valCuentaOrigen");
            Props.DataList.Add(GenProp("valCuentaOrigen", valCuentaOrigen));

            if (codTipoCuentaDestino.Trim() == "1")
            {
                Props.DataList.Add(GenProp("familia", "CTAS"));
                Props.DataList.Add(GenProp("grupo", "CTA01"));
                Props.DataList.Add(GenProp("codigoProducto", "1"));
            }
            else if (codTipoCuentaDestino.Trim() == "6")
            {
                Props.DataList.Add(GenProp("familia", "CTAS"));
                Props.DataList.Add(GenProp("grupo", "CTA02"));
                Props.DataList.Add(GenProp("codigoProducto", "6"));
            }
            else
            {
                Props.DataList.Add(GenProp("familia", "CTAS"));
                Props.DataList.Add(GenProp("grupo", "CTA03"));
                Props.DataList.Add(GenProp("codigoProducto", codTipoCuentaDestino));
            }

            var monedaOrigen = _cybi0060cl.GetValue("monedaOrigen");
            Props.DataList.Add(GenProp("monedaOrigen", monedaOrigen));

            var tipoCtaDestino = _cybi0060cl.GetValue("tipoCtaDestino");
            Props.DataList.Add(GenProp("tipoCtaDestino", tipoCtaDestino));

            var tipoProductoDestino = _cybi0060cl.GetValue("codTipoCuentaDestino");
            Props.DataList.Add(GenProp("tipoProductoDestino", tipoProductoDestino));

            var tipoCtaOrigen = _cybi0060cl.GetValue("tipoCtaOrigen");
            Props.DataList.Add(GenProp("tipoCtaOrigen", tipoCtaOrigen));

            return Props;
        }

        public Data GenProp(string valNombre, string valValor)
        {

            Data propiedadAdicional = new Data
            {
                HasData = true,
                Field = "PropiedadAdicional",
                DataList = new List<Data>()
            };

            Data DtoValNombre = new Data
            {
                Field = "valNombre",
                HasData = true,
                Value = valNombre
            };

            Data DtoValValor = new Data
            {
                Field = "valValor",
                HasData = true,
                Value = valValor
            };
            propiedadAdicional.DataList.Add(DtoValNombre);
            propiedadAdicional.DataList.Add(DtoValValor);

            return propiedadAdicional;

        }
        //Porpiedades Adicionales Para seguros 
        public Data AdicionalesSeguros()
        {
            Data PAdicionales = new Data()
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };
            PAdicionales.DataList.Add(GenProp("tipo seguro", _cybi0060cl.GetValue("TIXCTAFD").ToString().Trim()));
            PAdicionales.DataList.Add(GenProp("POLIZA", _cybi0060cl.GetValue("NUXCTAD").ToString().Trim()));
            PAdicionales.DataList.Add(GenProp("Expediente", _cybi0060cl.GetValue("COXBCO").ToString().Trim()));
            PAdicionales.DataList.Add(GenProp("valCuentaOrigen", _cybi0060cl.GetValue("NUXCTAO").ToString().Trim()));
            PAdicionales.DataList.Add(GenProp("monedaOrigen", _cybi0060cl.GetValue("COXMONO").ToString().Trim()));
            PAdicionales.DataList.Add(GenProp("tipoProducto", _cybi0060cl.GetValue("TIXCTAFD").ToString().Trim()));

            return PAdicionales;
        }




        public Data GetProps2(EasyMappingTool item)
        {
            //Familia, Tipo de producto, grupo, codigo
            var codTipoCuentaDestino = item.GetValue("TIPCTAFD").ToString();

            Data Props = new Data()
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };
            var valCuentaOrigen = item.GetValue("NUMCTAO");
            Props.DataList.Add(GenProp("valCuentaOrigen", valCuentaOrigen));

            if (codTipoCuentaDestino.Trim() == "1")
            {
                Props.DataList.Add(GenProp("familia", "CTAS"));
                Props.DataList.Add(GenProp("grupo", "CTA01"));
                Props.DataList.Add(GenProp("codigoProducto", "1"));
            }
            else if (codTipoCuentaDestino.Trim() == "6")
            {
                Props.DataList.Add(GenProp("familia", "CTAS"));
                Props.DataList.Add(GenProp("grupo", "CTA02"));
                Props.DataList.Add(GenProp("codigoProducto", "6"));
            }
            else
            {
                Props.DataList.Add(GenProp("familia", "CTAS"));
                Props.DataList.Add(GenProp("grupo", "CTA03"));
                Props.DataList.Add(GenProp("codigoProducto", codTipoCuentaDestino));
            }

            var monedaOrigen = item.GetValue("CODMONO");
            Props.DataList.Add(GenProp("monedaOrigen", monedaOrigen));

            var tipoCtaDestino = item.GetValue("CODTIPTRN");
            Props.DataList.Add(GenProp("tipoCtaDestino", tipoCtaDestino));

            var tipoProductoDestino = item.GetValue("TIPCTAFD");
            Props.DataList.Add(GenProp("tipoProductoDestino", tipoProductoDestino));

            var tipoCtaOrigen = item.GetValue("TIPCTAFO");
            Props.DataList.Add(GenProp("tipoCtaOrigen", tipoCtaOrigen));

            return Props;
        }
    }
}



