﻿using Domain.Entities;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;

namespace Infrastructure.Helpers
{
    public class PropiedadesAdicionales
    {
        private readonly OleDbConnection _oleDbConnection;
        private EasyMappingTool clProgram;
        private ISunitpService _sunitpService;
        public PropiedadesAdicionales(ISunitpService sunitpService)
        {
            _sunitpService = sunitpService;
        }

        public void SetData(Data registro, int bandera, EasyMappingTool clProgram)
        {
            foreach (Data item in registro.DataList)
            {

                foreach (Data dato in item.DataList)
                {
                    switch (dato.Field)
                    {
                        case "tipoCtaDestino":
                            clProgram.SetValue("codTipoCuentaDestino", dato.Value);
                            break;

                        case "valCuentaOrigen":
                            clProgram.SetValue("valCuentaOrigen", dato.Value);
                            break;

                        case "tipoCtaOrigen":
                            clProgram.SetValue("tipoProducto", dato.Value);
                            break;

                        case "codTipoTransaccion":
                            clProgram.SetValue("tipoCtaDestino", dato.Value);
                            break;
                    }
                }
                try
                {
                    var cuentas = from value in item.DataList
                                  where item.Field == "numeroDeCuenta"
                                  select item.Value;
                    if (!cuentas.Count().Equals(0))
                    {
                        foreach (string cuenta in cuentas)
                        {
                            clProgram.SetValue("valCuentaDestino", cuenta);

                            //CallModel
                            EasyDataModels edm = new EasyDataModels();
                            edm.EasyCallInit(_oleDbConnection, clProgram);
                            edm.CallProcedure();
                            //_sunitpService.AddObjLog("ConsultaCunetasFavoritas DoProcess", "00000000000000000000", "OBJETO RECIBIDO", clProgram.GetObject());


                            if (edm.IsSuccessful())
                            {
                                Data propiedades = NombreValor(clProgram, item, bandera);
                                item.DataList.Add(propiedades);
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    _sunitpService.AddSingleLog($"{ex.Message}");
                }

            }
        }

        private Data NombreValor(EasyMappingTool clProgram, Data registro, int bandera)
        {

            Data proAdicionales = new Data
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };



            foreach (KeyValuePair<string, EasyParameter> item in clProgram.GetParameters())
            {
                string key = item.Key;
                EasyParameter easy = item.Value;

                if (!key.Equals("valCuentaDestino") && !key.Equals("codTipoCuentaDestino") && !key.Equals("_defaultError"))
                {
                    Data valNombre = new Data
                    {
                        Field = "valNombre",
                        HasData = true,
                        Value = key
                    };

                    Data valValor = new Data
                    {
                        Field = "valValor",
                        HasData = true
                    };

                    switch (valNombre.Value)
                    {
                        case "tipoProducto":
                            valValor.Value = (bandera.Equals(1)) ? valValor.Value = clProgram.GetValue("tipoProducto") :
                            //valValor.Value = DataAdicionalResponse.DatosAdicionales(registro, "codigoProducto");
                            valValor.Value = DataAdicionalResponse.DatosAdicionales(registro, "tipoCtaOrigen");
                            break;
                        case "tipoCtaDestino":
                            if (bandera.Equals(1)) { valValor.Value = DataAdicionalResponse.DatosAdicionales(registro, "tipoCtaDestino"); }
                            valValor.Value = clProgram.GetValue("tipoCtaDestino");
                            break;
                        case "valCuentaOrigen":
                            valValor.Value = DataAdicionalResponse.DatosAdicionales(registro, "valCuentaOrigen");
                            //valValor.Value = clProgram.GetValue("valCuentaOrigen");
                            break;
                        case "monedaOrigen":
                            valValor.Value = DataAdicionalResponse.DatosAdicionales(registro, "monedaOrigen");
                            //valValor.Value = clProgram.GetValue("valCuentaOrigen");
                            break;
                        case "codigoProducto":
                            valValor.Value = (bandera.Equals(1)) ? valValor.Value = clProgram.GetValue("codigoProducto") :
                            valValor.Value = DataAdicionalResponse.DatosAdicionales(registro, "tipoCtaOrigen");
                            //valValor.Value = clProgram.GetValue("valCuentaOrigen");
                            break;
                        default:
                            valValor.Value = easy.value;
                            break;
                    }
                    Data response = new Data
                    {
                        Field = "PropiedadAdicional",
                        HasData = true,
                        DataList = new List<Data>()
                    };

                    response.DataList.Add(valNombre);
                    response.DataList.Add(valValor);




                    //agregar lista al encabezado
                    proAdicionales.HasData = true;
                    proAdicionales.DataList.Add(response);

                }
            }

            DataAdicionalResponse.Adicionar(registro, proAdicionales);

            return proAdicionales;
        }

    }
}
