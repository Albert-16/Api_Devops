﻿using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using SUNITP.LIB.ManagerProcedures;
using System.Collections.Generic;

namespace Infrastructure.Helpers
{
    public class ValidarRegistrosConsultasHelper
    {
        private readonly ISunitpService _sunitpService;
        public ValidarRegistrosConsultasHelper(ISunitpService sunitpService)
        {
            _sunitpService = sunitpService;
        }

        public bool ValidarRegistros(List<EasyMappingTool> response)
        {

            if (response.Count.Equals(1))
            {
                foreach (EasyMappingTool item in response)
                {
                    if (!item.GetValue("_defaultError").Equals(""))
                    {
                        _sunitpService.AddSingleLog(item.GetValue("_defaultError"));
                        return false;
                    }
                }
            }

            return true;
        }


        public Data Listas(Data lista, Data encabezado)
        {

            foreach (Data registro in lista.DataList)
            {
                encabezado.DataList.Add(registro);
            }

            encabezado.HasData = true;
            return encabezado;
        }


        public int Paginacion(EasyMappingTool cyb00035cl, int registroSiguiente, int contador)
        {
            int archivoContinuacion = registroSiguiente;

            //Encontrar el archivo anterior
            int recorrer = (archivoContinuacion.Equals(0)) ? (archivoContinuacion + 250) : (archivoContinuacion + 250) - 1;
            int anterior = archivoContinuacion - 250;
            anterior = (anterior <= 1) ? 0 : anterior;

            //Encontrar el archivo de continuacion
            archivoContinuacion = (archivoContinuacion.Equals(0)) ? archivoContinuacion + 251 : archivoContinuacion + 250;
            archivoContinuacion = (archivoContinuacion > contador) ? 0 : archivoContinuacion;

            cyb00035cl.SetValue("valTalonRegistroAnterior", anterior.ToString());
            cyb00035cl.SetValue("archivoContinuacion", archivoContinuacion.ToString());

            return recorrer;
        }
    }

}
