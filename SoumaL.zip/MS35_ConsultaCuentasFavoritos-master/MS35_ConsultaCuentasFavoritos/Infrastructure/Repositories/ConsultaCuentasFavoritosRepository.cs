﻿using Domain.Entities;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.ARepositories;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.Repository;
using Infrastructure.Helpers;
using System.Collections.Generic;

namespace Infrastructure.Repositories
{
    public class ConsultaCuentasFavoritosRepository : AEasyDataProcessRepository
    {

        public ConsultaCuentasFavoritosRepository() { }

        public override bool NeedDataBaseConnection => true;

        public override Data DoProcess(ISunitpService _sunitpService, Data data)
        {
            Data dataResponse = new Data
            {
                HasData = true,
                Field = "RESPONSE",
                Error = "00000000000000000000",
                ExternalError = "PROCESO REALIZADO CORRECTAMENTE",
                DataList = new List<Data>()
            };

            if (!data.Field.Equals("REQUEST_DETAIL"))
            {
                dataResponse.Error = "10000000000000000007";
                dataResponse.ExternalError = "NO SE HAN ENCONTRADO LOS PARAMETROS NECESARIOS PARA EL REQUEST";
                return dataResponse;
            }

            //MapRequest
            CYB00035CL cyb00035cl = new CYB00035CL();
            RequestObjectMapper rom = new RequestObjectMapper();
            rom.Map(cyb00035cl, data);
            _sunitpService.AddObjLog("ConsultaCunetasFavoritas DoProcess", "00000000000000000000", "OBJETO MAPEADO", cyb00035cl.GetObject());


            //llamado a las cuentas favoritas
            LlamadaCoreHelper lca = new LlamadaCoreHelper(_sunitpService, _oledbConnection);
            dataResponse = lca.Call(dataResponse, cyb00035cl);

            return dataResponse;
        }
    }
}
