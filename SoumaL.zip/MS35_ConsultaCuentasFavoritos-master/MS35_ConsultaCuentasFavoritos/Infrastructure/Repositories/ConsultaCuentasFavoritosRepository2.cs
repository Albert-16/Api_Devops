﻿using Domain.Entities;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.ARepositories;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using EasyTemplateSolution.Infrastructure.Repository;
using Infrastructure.Dictionaries;
using Infrastructure.Helpers;
using Infrastructure.Utilities;
using Infrastructure.Utillities;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using SUNITP.LIB.QueryStringGenerator;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Linq;

namespace Infrastructure.Repositories
{
    public class ConsultaCuentasFavoritosRepository2 : AEasyDataProcessRepository
    {

        public ConsultaCuentasFavoritosRepository2() { }

        public override bool NeedDataBaseConnection => true;

        public override Data DoProcess(ISunitpService _sunitpService, Data data)
        {
            string[] tabla = { "IFAV1", "IFAV2", "IFAV3", "IFAV4", "IFAV5", "IFAV6",
                                "IFAV7", "IFAV8", "IFAV9", "IFAV10", "IFAV11", "IFAV12", "IFAV13",
                               "IFAV14", "IFAV15", "IFAV16" };

            Data dataResponse = new Data
            {
                HasData = true,
                Field = "RESPONSE",
                Error = "00000000000000000000",
                ExternalError = "PROCESO REALIZADO CORRECTAMENTE",
                DataList = new List<Data>()
            };

            if (!data.Field.Equals("REQUEST_DETAIL"))
            {
                dataResponse.Error = "10000000000000000007";
                dataResponse.ExternalError = "NO SE HAN ENCONTRADO LOS PARAMETROS NECESARIOS PARA EL REQUEST";
                return dataResponse;
            }

            //MapRequest
            CYB00035CL cyb00035cl = new CYB00035CL();
            RequestObjectMapper rom = new RequestObjectMapper();
            rom.Map(cyb00035cl, data);


            var edm = new EasyDataModels();
            edm.EasyCallInit(_oledbConnection, cyb00035cl);
            edm.CallProcedure();


            _sunitpService.AddObjLog("ConsultaCunetasFavoritas DoProcess", "00000000000000000000", "OBJETO MAPEADO", cyb00035cl.GetObject());




            //Me sirven para debito sinpe 
            var codTipoCuentaDestino = cyb00035cl.GetValue("codTipoCuentaDestino");
            var codTipoTransaccion = cyb00035cl.GetValue("codTipoTransaccion");

            //Generales
            var numeroIdentificacion = cyb00035cl.GetValue("numeroIdentificacion");
            var tipoIdentificacion = cyb00035cl.GetValue("tipoIdentificacion");
            var canal = cyb00035cl.GetValue("canal");
            
            //Datos de Filtro
            var tipoCuentaACH = "%" + cyb00035cl.GetValue("tipoCuentaACH").Trim() + "%";
            var cuentaACH = "%" + cyb00035cl.GetValue("cuentaACH").Trim() + "%";
            var valNombreTitular = "%" + cyb00035cl.GetValue("valNombreTitular").Trim() + "%";
            var valAlias = "%" + cyb00035cl.GetValue("valAlias").Trim() + "%";
            var valCuentaDestino = "%" + cyb00035cl.GetValue("valCuentaDestino").Trim() + "%";
            //var codTipoCuentaDestino = cyb00035cl.GetValue("codTipoCuentaDestino").Trim();

            //******************************************************************************************
            if (cyb00035cl.GetValue("modoDeOperacion").Equals("2"))
            {
                //obteniendo cuenta
                switch (codTipoCuentaDestino)
                {
                    case "P"://prestamos
                        codTipoCuentaDestino = "50";
                        break;
                    case "S"://
                        codTipoCuentaDestino = "60";
                        break;
                    case "T"://Tarjetas de credito
                        codTipoCuentaDestino = "89";
                        break;
                    case "G"://Seguros
                        codTipoCuentaDestino = "G";
                        break;
                    default://todos los productos 
                        codTipoCuentaDestino = "A";
                        break;
                }


                //EasyParameter TiXCtaFD = CrearParametros.CreateEasyParameter("TiXCtaFD", ParameterDirection.Input, codTipoCuentaDestino, OleDbType.Char, 100, 0);
                //EasyParameter CTipTrn = CrearParametros.CreateEasyParameter("CTipTrn", ParameterDirection.Input, codTipoTransaccion, OleDbType.VarChar, 20, 0);
                EasyParameter NuXIdeO = CrearParametros.CreateEasyParameter("NuXIdeO", ParameterDirection.Input, numeroIdentificacion, OleDbType.Char, 100, 0);
                string tipo = codTipoCuentaDestino == "G" ? "TIXCTAFO" : "TIXCTAFD";
                EasyParameter TIXCTAFD = CrearParametros.CreateEasyParameter(tipo, ParameterDirection.Input, codTipoCuentaDestino, OleDbType.Char, 100, 0);
                ServiceQueryStringGenerator sqs = new ServiceQueryStringGenerator();
                sqs._iQueryStringGenerator.From("CYBERDTA", "ITCYBFAV");
                // sqs._iQueryStringGenerator.WhereAnd(TiXCtaFD, "=");
                // sqs._iQueryStringGenerator.WhereAnd(CTipTrn, "=");
                if (!codTipoCuentaDestino.Equals("A"))
                {
                    sqs._iQueryStringGenerator.WhereAnd(TIXCTAFD, "=");
                }
                sqs._iQueryStringGenerator.WhereAnd(NuXIdeO, "=");
                sqs._iQueryStringGenerator.OrderByDesc("TIXCTAFD");
                sqs._iQueryStringGenerator.SelectAll();
                EasyCrudDataModels ecdmRespon = new EasyCrudDataModels(_oledbConnection);
                List<EasyMappingTool> registrosQueryResult = ecdmRespon.SelectExecute(sqs);


                Data Registros = CrearParametros.GetData2("Registros", "0", "", true);
                int i = 1;
                var archivoContinuacion = cyb00035cl.GetValue("registroSiguiente");
                archivoContinuacion = (archivoContinuacion.Trim() == "") ? "0" : archivoContinuacion;
                var cant = 0;
                var inicio = int.Parse(archivoContinuacion);
                int final = inicio + 255;//to-do Jose Leon limit y offset en la quiery a generar sedebera de establecer el limit y offset para pdoer mandar la paginacion al as400 y evitar recorrer
                string seguro;
                if (!registrosQueryResult.Count.Equals(0)) // to-do Jose Leon, invertir este if para hacer el flujo limpio 
                {
                    foreach (EasyMappingTool registro in registrosQueryResult)
                    {




                        var cybi0060cl = new CYBI0060CL();
                        if (i >= inicio && i <= final)
                        {



                            Data Registro = CrearParametros.GetData2("Registro", i.ToString(), "", true);
                            seguro = registro.GetValue("TIXCTAFO").Trim().ToString();
                            Dictionary<string, string> tipoo = seguro == "G" ?
                                TableDictionaries.ProductosGS() :
                                TableDictionaries.ProductosTP(); //to-do Jose Leon corregir este antipatron con decoradores de las tablas que se consumen. desplegar la funcion para mas ejemplo





                            foreach (KeyValuePair<string, string> item in tipoo)
                            {
                                string field = item.Value;
                                string value = registro.GetValue(item.Key);
                                switch (field)
                                {
                                    case "tipoCtaDestino":
                                        cybi0060cl.SetValue("codTipoCuentaDestino", value);
                                        break;
                                    case "codTipoTransaccion":
                                        cybi0060cl.SetValue("tipoCtaDestino", value);
                                        break;
                                    case "monedaOrigen":
                                        cybi0060cl.SetValue("monedaOrigen", value);
                                        break;

                                    case "tipoProductoDestino":
                                        cybi0060cl.SetValue("tipoProductoDestino", value);
                                        break;
                                    case "valCuentaOrigen":
                                        cybi0060cl.SetValue("valCuentaOrigen", value);
                                        break;
                                    case "tipoCtaOrigen":
                                        cybi0060cl.SetValue("tipoCtaOrigen", value);
                                        break;
                                }
                                Registro.DataList.Add(CrearParametros.GetData(field.Trim(), value.Trim()));

                            }

                            i++;
                            if (seguro == "G")
                            {
                                PropiedadesAdicionales props = new PropiedadesAdicionales(registro);
                                Registro.DataList.Add(props.AdicionalesSeguros());
                                Registros.DataList.Add(Registro);
                            }
                            else
                            {
                                PropiedadesAdicionales props = new PropiedadesAdicionales(cybi0060cl);
                                Registro.DataList.Add(props.GetProps());
                                Registros.DataList.Add(Registro);
                            }

                        }

                    }
                }
                else
                {
                    cyb00035cl.SetValue("codMsgRespuesta", "180306");//"180306"); //211
                    cyb00035cl.SetValue("msgRespuesta", "No posee productos inscritos para esta funcionalidad"); //"Actualmente no tiene inscritos que le permitan usar esta opción.");//No posee productos inscritos para esta funcionalidad
                    cyb00035cl.SetValue("caracterAceptacion", "M");
                }

                //to-do Jose Leon 
                // if registrosQueryResult.Count.Equals(0) 
                //      return error de negocio...
                //si no es vacio el proceso normal de transformacion de datos.


                if (archivoContinuacion.Trim() == "") { archivoContinuacion = "0"; }
                if (archivoContinuacion.Trim() == "0")
                {
                    if (cant > 250)
                    {
                        cyb00035cl.SetValue("archivoContinuacion", "251");
                        cyb00035cl.SetValue("valTalonRegistroAnterior", "0");

                    }
                    else
                    {
                        cyb00035cl.SetValue("archivoContinuacion", "0");
                        cyb00035cl.SetValue("valTalonRegistroAnterior", "0");
                    }
                    cyb00035cl.SetValue("cantidadRegistros", cant.ToString());

                }
                else
                {
                    var cantRegistros = cant - inicio;
                    cyb00035cl.SetValue("cantidadRegistros", cantRegistros.ToString());
                    var valArchivoContinuacion = int.Parse(archivoContinuacion);
                    if ((cant - inicio) > 250)
                    {
                        cyb00035cl.SetValue("valTalonRegistroAnterior", valArchivoContinuacion.ToString());
                        valArchivoContinuacion = valArchivoContinuacion + 250;
                        cyb00035cl.SetValue("archivoContinuacion", valArchivoContinuacion.ToString().Trim());
                    }
                    else
                    {
                        cyb00035cl.SetValue("archivoContinuacion", "0");
                        valArchivoContinuacion = (valArchivoContinuacion - 250 == 1) ? 0 : (valArchivoContinuacion - 250);

                        cyb00035cl.SetValue("valTalonRegistroAnterior", valArchivoContinuacion.ToString());

                    }
                }

                var rdm = new ResponseDataMapper("", "RESPONSE", "", "00000000000000000000", "PROCESO REALIZADO EXITOSAMENTE", "");
                dataResponse = rdm.Map(cyb00035cl);

                dataResponse.DataList.Add(Registros);

            }

            //*****************************************************************************************
            else
            {

                if (codTipoCuentaDestino == "S" && codTipoTransaccion == "C")//DESTINOS AUTORIZADOS
                {
                    var destinosAutorizadosResponse = new DestionsAutorizadosRepository();
                    destinosAutorizadosResponse.Buscar(_sunitpService, dataResponse, cyb00035cl, _oledbConnection); //to-do validar
                }
                else
                {
                    var sqsg = QueryMaker(tabla, numeroIdentificacion, tipoCuentaACH, cuentaACH, 
                        valNombreTitular, valAlias, valCuentaDestino, codTipoCuentaDestino, canal);

                    var query = sqsg._iQueryStringGenerator.GetQueryStatement();
                    var params2 = sqsg._iQueryStringGenerator.GetParameterCollection();
                    var ecdm = new EasyCrudDataModels(_oledbConnection);
                    var response = ecdm.SelectExecute(sqsg);


                    //MAPEO DE LA RESPUESTA
                    if (cyb00035cl.GetValue("canal").Equals("4"))
                    {
                        //--NUMCTAD--NUMIDEO
                        var listado = new List<EasyMappingTool>();
                        listado = response;
                        var listado2 = new List<EasyMappingTool>();

                        foreach (var row in response)
                        {
                            if (row.GetValue("TIPCTAFD").Equals("CU"))
                            {
                                row.SetValue("TIPCTAFD", "1");
                            }
                            if (row.GetValue("TIPCTAFD").Equals("PR"))
                            {
                                row.SetValue("TIPCTAFD", "3");
                            }
                            if (row.GetValue("TIPCTAFD").Equals("TA"))
                            {
                                row.SetValue("TIPCTAFD", "4");
                            }

                            bool exist = false;

                            string cuentaD = row.GetValue("NUMCTAD").ToString();
                            string IDcuenta = row.GetValue("NUMIDEO").ToString();
                            foreach (var row2 in listado2)
                            {
                                string cuentaD2 = row2.GetValue("NUMCTAD").ToString();
                                string IDcuenta2 = row2.GetValue("NUMIDEO").ToString();
                                if (cuentaD2 == cuentaD && IDcuenta2 == IDcuenta)
                                {
                                    string fechast1 = row2.GetValue("FCHFAVCR");
                                    string fechast2 = row.GetValue("FCHFAVCR");
                                    string forma = "dd/MM/yyyy'T'HH:mm:sszzz";
                                    DateTime fecha = DateTime.ParseExact(fechast1, forma, CultureInfo.InvariantCulture);
                                    DateTime fecha2 = DateTime.ParseExact(fechast2, forma, CultureInfo.InvariantCulture);
                                    if (fecha2 > fecha)
                                    {
                                        listado2.Remove(row2);
                                        break;
                                    }
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist)
                            {
                                listado2.Add(row);
                            }
                        }
                        response = listado2;
                    }


                    //Obtener los Correos 
                    
                    ServiceQueryStringGenerator sqsgQr = new ServiceQueryStringGenerator();
                    sqsgQr._iQueryStringGenerator.SelectAll();
                    sqsgQr._iQueryStringGenerator.From("CYBERDTA", "ICYBFAVC03");
                    sqsgQr._iQueryStringGenerator.Where(CrearParametros.CreateEasyParameter("NUMIDEO", ParameterDirection.InputOutput, numeroIdentificacion, OleDbType.VarChar, 20), "=");
                    EasyCrudDataModels ecdsel = new EasyCrudDataModels(_oledbConnection);
                    List<EasyMappingTool> resultqy = ecdsel.SelectExecute(sqsgQr);

                    /*resultqy= (from item in resultqy
                               where item.GetValue("GUIDCOR") == "bf47b047-3519-40f5-9da4-b0716315221c"
                               select item).ToList();*/



                    var cybi0060cl = new CYBI0060CL();
                    var nameTagMapper = new Mapper(_sunitpService, _oledbConnection, cybi0060cl);
                    var cant = 0;
                    var archivoContinuacion = cyb00035cl.GetValue("registroSiguiente");
                    archivoContinuacion = (archivoContinuacion.Trim() == "") ? "0" : archivoContinuacion;
                    var inicio = int.Parse(archivoContinuacion);
                    //to-do Jose Leon 
                    // Refactor mismo problema es una funcion que recorreo entidades para mapear.
                    Data tags =
                    nameTagMapper.MapData(response, TableDictionaries.CybFavDictionary(), "Registro", inicio, 1, codTipoCuentaDestino, ref cant, resultqy);
                    var rdm = new ResponseDataMapper("", "RESPONSE", "", "00000000000000000000", "PROCESO REALIZADO EXITOSAMENTE", "");

                    // tags.DataList.Count;
                    if (archivoContinuacion.Trim() == "") { archivoContinuacion = "0"; }
                    if (archivoContinuacion.Trim() == "0")
                    {
                        if (cant > 250)
                        {
                            cyb00035cl.SetValue("archivoContinuacion", "251");
                            cyb00035cl.SetValue("valTalonRegistroAnterior", "0");

                        }
                        else
                        {
                            cyb00035cl.SetValue("archivoContinuacion", "0");
                            cyb00035cl.SetValue("valTalonRegistroAnterior", "0");
                        }
                        cyb00035cl.SetValue("cantidadRegistros", cant.ToString());

                    }
                    else
                    {
                        var cantRegistros = cant - inicio;
                        cyb00035cl.SetValue("cantidadRegistros", cantRegistros.ToString());
                        var valArchivoContinuacion = int.Parse(archivoContinuacion);
                        if ((cant - inicio) > 250)
                        {
                            cyb00035cl.SetValue("valTalonRegistroAnterior", valArchivoContinuacion.ToString());
                            valArchivoContinuacion = valArchivoContinuacion + 250;
                            cyb00035cl.SetValue("archivoContinuacion", valArchivoContinuacion.ToString().Trim());
                        }
                        else
                        {
                            cyb00035cl.SetValue("archivoContinuacion", "0");
                            valArchivoContinuacion = (valArchivoContinuacion - 250 == 1) ? 0 : (valArchivoContinuacion - 250);

                            cyb00035cl.SetValue("valTalonRegistroAnterior", valArchivoContinuacion.ToString());

                        }
                    }
                    // Buscan Resgistros para evaluar si tiene productos 
                    Data Registro = (from item in tags.DataList
                                     where item.Field == "Registro"
                                     select item).FirstOrDefault();
                    //to-do Jose Leon
                    // esta validacion ne es necesario que se comprube e de esta forma podria basarse en la informacion de resultqy que es la consulta
                    // si esa consulta no trae nada se setean esos errores y se envia la response, no como actualmente se realiza que se tiene que mapear para poder validar.
                    if (Registro == null)
                    {
                        cyb00035cl.SetValue("codMsgRespuesta", "180306");// "180306"); //211
                        cyb00035cl.SetValue("msgRespuesta", "No posee productos inscritos para esta funcionalidad");// "Actualmente no tiene inscritos que le permitan usar esta opción");//No posee productos inscritos para esta funcionalidad
                        cyb00035cl.SetValue("caracterAceptacion", "M");
                    }



                    dataResponse = rdm.Map(cyb00035cl);
                    dataResponse.DataList.Add(tags);
                }

            }




            //llamado a las cuentas favoritas

            return dataResponse;
        }
        public ServiceQueryStringGenerator QueryMaker(string[] tablas, string numeroIdentificacion, 
            string tipoCuentaACH, string cuentaACH, string valNombreTitular, string valAlias, 
             string valCuentaDestino, string codTipoCuentaDestino, string canal)
        {
            var fQuery = new FieldsQuery();
            var sqsg = new ServiceQueryStringGenerator();
            var pNumeroIdentificacion = fQuery.fieldQuery("NUMIDEO", numeroIdentificacion, OleDbType.VarChar, 20);
            var pValNombreTitular = fQuery.fieldQuery("NOMTIT", valNombreTitular, OleDbType.VarChar, 150);
            //var pcodTipoCuentaDestino = fQuery.fieldQuery("CODTIPTRN", codTipoCuentaDestino, OleDbType.VarChar, 1);
            var pValAlias = fQuery.fieldQuery("VALALIAS", valAlias, OleDbType.VarChar, 120);
            var pValCuentaDestino = fQuery.fieldQuery("NUMCTAD", valCuentaDestino, OleDbType.VarChar, 20);
            //var pTipoCuentaACH = fQuery.fieldQuery("TIPCTAFO", tipoCuentaACH, OleDbType.VarChar, 2);
            var pCuentaACH = fQuery.fieldQuery("NUMCTAO", cuentaACH, OleDbType.VarChar, 20);
            var DCodBan = fQuery.fieldQuery("BCODES", "", OleDbType.VarChar, 20);
            sqsg._iQueryStringGenerator.SelectAll();


            var escenario = 0;
            if (!v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {

                sqsg._iQueryStringGenerator.WhereAnd(DCodBan, "<>");
                sqsg._iQueryStringGenerator.Where(pNumeroIdentificacion, "=");

                escenario = 1;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                escenario = 2;
            }
            else if (!v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                escenario = 3;

            }
            else if (!v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 4;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                escenario = 5;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");

                escenario = 6;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");
                escenario = 7;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                escenario = 8;
            }
            else if (!v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 9;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");

                escenario = 10;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 11;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");


                escenario = 12;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");

                escenario = 13;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 14;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 15;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 16;
            }
            sqsg._iQueryStringGenerator.From("CYBERDTA", tablas[escenario - 1]);

            return sqsg;
        }
        public bool v(string variable)
        {
            if (variable.Trim() == "%%")
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
