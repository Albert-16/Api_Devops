﻿using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.Repository;
using Infrastructure.Dictionaries;
using Infrastructure.Helpers;
using Infrastructure.Utillities;
using SUNITP.LIB.ManagerProcedures;
using SUNITP.LIB.ManagerProcedures.Concrete;
using SUNITP.LIB.QueryStringGenerator;
using System.Data.OleDb;


namespace Infrastructure.Repositories
{
    public class DestionsAutorizadosRepository
    {

        public Data Buscar(ISunitpService _sunitpService, Data dataresponse, EasyMappingTool cyb00035cl, OleDbConnection _oledbConnection)
        {
            string[] tabla = { "IFVS1", "IFVS2", "IFVS3", "IFVS4", "IFVS5", "IFVS6",
                                "IFVS7", "IFVS8", "IFVS9", "IFVS10", "IFVS11", "IFVS12", "IFVS13",
                               "IFVS14", "IFVS15", "IFVS16" };




            RequestObjectMapper rom = new RequestObjectMapper();
            rom.Map(cyb00035cl, dataresponse);
            _sunitpService.AddObjLog("ConsultaCunetasFavoritas DoProcess", "00000000000000000000", "OBJETO MAPEADO", cyb00035cl.GetObject());

            //Me sirven para debito sinpe
            var codTipoCuentaDestino = cyb00035cl.GetValue("codTipoCuentaDestino");
            var codTipoTransaccion = cyb00035cl.GetValue("codTipoTransaccion");

            //Generales
            var numeroIdentificacion = cyb00035cl.GetValue("numeroIdentificacion");
            var tipoIdentificacion = cyb00035cl.GetValue("tipoIdentificacion");

            //Datos de Filtro
            var tipoCuentaACH = "%" + cyb00035cl.GetValue("tipoCuentaACH").Trim() + "%";
            var cuentaACH = "%" + cyb00035cl.GetValue("cuentaACH").Trim() + "%";
            var valNombreTitular = "%" + cyb00035cl.GetValue("valNombreTitular").Trim() + "%";
            var valAlias = "%" + cyb00035cl.GetValue("valAlias").Trim() + "%";
            var valCuentaDestino = "%" + cyb00035cl.GetValue("valCuentaDestino").Trim() + "%";


            var sqsg = QueryMaker(tabla, numeroIdentificacion, tipoCuentaACH, cuentaACH, valNombreTitular, valAlias, valCuentaDestino);
            var query = sqsg._iQueryStringGenerator.GetQueryStatement();
            var params2 = sqsg._iQueryStringGenerator.GetParameterCollection();

            var ecdm = new EasyCrudDataModels(_oledbConnection);
            var response = ecdm.SelectExecute(sqsg); //to-do Jose Leon validar si esta query es realmente util.
            //ya que esta funcion retorna "dataresponse" y esa variable es la ejecucion de la cl

            //llamado a las cuentas favoritas
            LlamadaCoreHelper lca = new LlamadaCoreHelper(_sunitpService, _oledbConnection);
            dataresponse = lca.Call(dataresponse, cyb00035cl);
            var cant = 0;
            var nameTagMapper = new Mapper();
            //Data tags = nameTagMapper.MapData(response, TableDictionaries.CamposCuentasDavivienda(), "Registro", 0, 0, codTipoCuentaDestino, ref cant);
            //dataresponse.DataList.Add(tags);

            return dataresponse;


        }

        public ServiceQueryStringGenerator QueryMaker(string[] tablas, string numeroIdentificacion, string tipoCuentaACH, string cuentaACH, string valNombreTitular, string valAlias, string valCuentaDestino)
        {


            var fQuery = new FieldsQuery();
            var sqsg = new ServiceQueryStringGenerator();
            var pNumeroIdentificacion = fQuery.fieldQuery("NumIde2", numeroIdentificacion, OleDbType.VarChar, 20);
            var pValNombreTitular = fQuery.fieldQuery("NomTi2", valNombreTitular, OleDbType.VarChar, 150);
            var pValAlias = fQuery.fieldQuery("VALALIA2", valAlias, OleDbType.VarChar, 120);
            var pValCuentaDestino = fQuery.fieldQuery("NUMCTAE2", valCuentaDestino, OleDbType.VarChar, 20);
            var pTipoCuentaACH = fQuery.fieldQuery("TIPCTAF2", tipoCuentaACH, OleDbType.VarChar, 2);
            var pCuentaACH = fQuery.fieldQuery("NumCta2", cuentaACH, OleDbType.VarChar, 20);
            sqsg._iQueryStringGenerator.SelectAll();


            var escenario = 0;
            if (!v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.Where(pNumeroIdentificacion, "=");

                escenario = 1;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                escenario = 2;
            }
            else if (!v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                escenario = 3;

            }
            else if (!v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 4;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                escenario = 5;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");

                escenario = 6;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");
                escenario = 7;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                escenario = 8;
            }
            else if (!v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 9;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");

                escenario = 10;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 11;
            }
            else if (!v(cuentaACH) && v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");


                escenario = 12;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && v(valAlias) && !v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");

                escenario = 13;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && !v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 14;
            }
            else if (v(cuentaACH) && !v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 15;
            }
            else if (v(cuentaACH) && v(valNombreTitular) && v(valAlias) && v(valCuentaDestino))
            {
                sqsg._iQueryStringGenerator.WhereAnd(pNumeroIdentificacion, "=");
                sqsg._iQueryStringGenerator.WhereAnd(pCuentaACH, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValNombreTitular, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValAlias, "LIKE");
                sqsg._iQueryStringGenerator.WhereAnd(pValCuentaDestino, "LIKE");

                escenario = 16;
            }
            sqsg._iQueryStringGenerator.From("CYBERDTA", tablas[escenario - 1]);

            return sqsg;
        }
        public bool v(string variable)
        {
            if (variable.Trim() == "%%")
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}