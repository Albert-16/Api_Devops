﻿using Domain.Entities.CYBERPGM;
using EasyTemplateSolution.DistributedServices.WsdlSunitpClient.Services;
using EasyTemplateSolution.Domain.ARepositories;
using EasyTemplateSolution.Domain.Dto;
using EasyTemplateSolution.Infrastructure.DataModels;
using EasyTemplateSolution.Infrastructure.Repository;
using System.Collections.Generic;

namespace Infrastructure.Repositories
{
    public class TestConnectionRepository : AEasyDataProcessRepository
    {
        public TestConnectionRepository() { }

        public override bool NeedDataBaseConnection => true;
        public override Data DoProcess(ISunitpService _sunitpService, Data data)
        {
            Data dataResponse = new Data
            {
                Error = "0000000000000000000",
                HasData = true,
                Field = "RESPONSE",
                ExternalError = "PROCESO REALIZADO CORRECTAMENTE",
                InternalError = "",
                DataList = new List<Data>()
            };

            if (!data.Field.Equals("REQUEST_DETAIL"))
            {
                dataResponse.Error = "10000000000000000007";
                dataResponse.ExternalError = "NO SE HAN ENCONTRADO LOS PARAMETROS NECESARIOS PARA EL REQUEST.";
                return dataResponse;
            }

            //MapRequest
            CYB00000CL cyb00000Cl = new CYB00000CL();

            RequestObjectMapper rom = new RequestObjectMapper();
            rom.Map(cyb00000Cl, data);
            _sunitpService.AddObjLog("AdministracionUsuarioCanalWebRepository DoProcess", "00000000000000000000", "OBJETO ENVIADO", cyb00000Cl.GetObject());

            //CallModel
            EasyDataModels edm = new EasyDataModels();
            edm.EasyCallInit(_oledbConnection, cyb00000Cl);
            edm.CallProcedure();
            _sunitpService.AddObjLog("AdministracionUsuarioCanalWebRepository DoProcess", "00000000000000000000", "OBJETO RECIBIDO", cyb00000Cl.GetObject());

            if (edm.IsSuccessful())
            {
                ResponseDataMapper rdm = new ResponseDataMapper("", "RESPONSE", "", "00000000000000000000", "PROCESO REALIZADO EXITOSAMENTE", "");
                dataResponse = rdm.Map(cyb00000Cl);
            }
            else
            {
                dataResponse.Error = "10000000000000000005";
                dataResponse.ExternalError = "ERROR AL MOMENTO DE LLAMAR AL PROCEDIMIENTO ALMACENADO.";
                dataResponse.InternalError = cyb00000Cl.GetValue("_defaultError");
            }
            return dataResponse;
        }
    }

}
