﻿using EasyTemplateSolution.Domain.Dto;
using SUNITP.LIB.ManagerProcedures.Concrete;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;

namespace Infrastructure.Utilities
{
    public static class CrearParametros
    {

        public static Data CreateData(string field, string value, bool isDataList = false, bool isDataResponse = false)
        {
            try
            {

                Data dataObj = new Data()
                {
                    Field = field,
                    HasData = (value != "" || isDataList) ? true : false,
                    Value = (value != "") ? value : null,
                    DataList = (isDataList || isDataResponse) ? new List<Data>() : null
                };
                if (isDataResponse)
                {
                    dataObj.Error = "00000000000000000000";
                    dataObj.ExternalError = "PROCESO REALIZADO CORRECTAMENTE";
                    dataObj.InternalError = "";
                }
                return dataObj;
            }
            catch (Exception ex)
            {
                Data dataObj = new Data()
                {
                    Field = "",
                    HasData = false,
                    Value = ""
                };

                return dataObj;
            }

        }

        public static EasyParameter CreateEasyParameter(string Field, ParameterDirection ParameterDirection, string Value, OleDbType Type, int Size)
        {
            return new EasyParameter()
            {
                field = Field,
                parameterDirection = ParameterDirection,
                value = Value,
                type = Type,
                size = Size
            };
        }

        public static EasyParameter CreateEasyParameter(string Field, ParameterDirection ParameterDirection, string Value, OleDbType Type, int Size, byte precision)
        {
            return new EasyParameter()
            {
                field = Field,
                parameterDirection = ParameterDirection,
                value = Value,
                type = Type,
                size = Size,
                precision = precision
            };
        }

        public static Data GetData(string Field, string Value = "", bool isDataList = false)
        {
            try
            {
                return new Data()
                {
                    Field = Field,
                    HasData = Value != "" || isDataList ? true : false,
                    Value = Value != "" ? Value : null,
                    DataList = isDataList ? new List<Data>() : null
                };
            }
            catch (Exception ex)
            {
                return new Data()
                {
                    Field = Field,
                    HasData = Value != "" || isDataList ? true : false,
                    Value = Value != "" ? Value : null,
                    DataList = isDataList ? new List<Data>() : null
                };
            }
        }

        public static Data GetData2(string Field, string id, string Value = "", bool isDataList = false)
        {
            try
            {
                return new Data()
                {
                    Field = Field,
                    Id = id,
                    HasData = Value != "" || isDataList ? true : false,
                    Value = Value != "" ? Value : null,
                    DataList = isDataList ? new List<Data>() : null
                };
            }
            catch (Exception ex)
            {
                return new Data()
                {
                    Field = Field,
                    Id = id,
                    HasData = Value != "" || isDataList ? true : false,
                    Value = Value != "" ? Value : null,
                    DataList = isDataList ? new List<Data>() : null
                };
            }
        }

    }
}
