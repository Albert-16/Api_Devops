﻿using System;

namespace Infrastructure.Utillities
{
    public static class ExceptionLogger
    {
        public static string GetException(Exception exception)
        {
            return $"Message: {exception.Message}\n StackTrace: {exception.StackTrace}\n InnerException: {exception.InnerException}\n Source: {exception.Source}\n Target: {exception.TargetSite}";
        }
    }
}
