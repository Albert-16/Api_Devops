﻿using SUNITP.LIB.ManagerProcedures.Concrete;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Utillities
{
    public class FieldsQuery
    {
        //Mapeo de campos para realizar la consulta
        public EasyParameter fieldQuery(string Field, string Value, OleDbType Type, int size)
        {

            var field = new EasyParameter();
            field.field = Field;
            field.size = size;
            field.scale = 0;
            field.type = Type;
            field.value = Value;
            field.precision = byte.Parse(size.ToString());
            return field;

        }

        public EasyParameter fieldQuery(string Field, string Value, OleDbType Type, int size, string Scala)
        {

            var field = new EasyParameter();
            field.field = Field;
            field.size = size;
            field.scale = byte.Parse(Scala);
            field.type = Type;
            field.value = Value;
            field.precision = byte.Parse(size.ToString());
            return field;

        }

    }
}
