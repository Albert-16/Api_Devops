﻿using EasyTemplateSolution.Domain.Dto;

namespace Infrastructure.Utillities
{
    public static class Formatters
    {
        public static string FormatDateHour(string fecha, string hour)
        {
            string anio = fecha.Substring(0, 4);
            string mes = fecha.Substring(4, 2);
            string dia = fecha.Substring(6, 2);

            string valor = $"{dia}/{mes}/{anio}T{hour}-06:00";

            return valor;
        }
        public static void ValBancoDestino(Data registro, string campoAExtraer, string campoAInsertar)
        {
            string valor = "";

            foreach (Data item in registro.DataList)
            {
                if (item.Field.Equals(campoAExtraer))
                {
                    valor = item.Value;
                }

                if (item.Field.Equals(campoAInsertar))
                {
                    item.Value = valor;
                }
            }
        }
    }
}
