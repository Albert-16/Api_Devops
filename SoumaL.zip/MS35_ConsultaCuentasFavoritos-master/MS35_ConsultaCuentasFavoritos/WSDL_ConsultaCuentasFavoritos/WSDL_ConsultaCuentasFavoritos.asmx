﻿<%@ WebService Language="C#" CodeBehind="WSDL_ConsultaCuentasFavoritos.asmx.cs" Class="WSDL_ConsultaCuentasFavoritos.WSDL_ConsultaCuentasFavoritos" %>
