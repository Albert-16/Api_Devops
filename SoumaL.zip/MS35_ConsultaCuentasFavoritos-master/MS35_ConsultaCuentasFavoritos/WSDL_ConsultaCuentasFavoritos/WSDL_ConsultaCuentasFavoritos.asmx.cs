﻿using Application;
using EasyTemplateSolution.Presentation.Decrypt;
using System.Diagnostics;
using System.Web.Services;

namespace WSDL_ConsultaCuentasFavoritos
{
    /// <summary>
    /// Summary description for WSDL_ConsultaCuentasFavoritos
    /// </summary>
    [WebService(Namespace = "http:/WSDL_ConsultaCuentasFavoritos/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WSDL_ConsultaCuentasFavoritos : WebService
    {

        [WebMethod]
        public string DoProcess(string DataTransferObject)
        {
            Stopwatch timeMeasure = new Stopwatch();
            timeMeasure.Start();

            DataDecryptAdapter dda = new DataDecryptAdapter();
            EasyTemplateSolution.Domain.Dto.DataTransferObject dto = dda.GetDataTransferObject(DataTransferObject);

            if (dto.Error.Equals("00000000000000000000"))
            {
                //Do Process
                ConsultaCuentasFavoritosService consultaCuentasFavoritos = new ConsultaCuentasFavoritosService();
                EasyTemplateSolution.Domain.Dto.DataTransferObject response = consultaCuentasFavoritos.DoProcess(dto);
                string dtoResponse = dda.GetDataTransferObjectString(response);

                timeMeasure.Stop();
                long tiempo = timeMeasure.ElapsedMilliseconds;

                return dtoResponse;
            }
            else
            {
                string dtoResponse = dda.GetDataTransferObjectString(dto);
                return dtoResponse;
            }
        }
    }
}
