# MS35_ConsultaCuentasFavoritos
Consulta de Cuentas Favoritos
