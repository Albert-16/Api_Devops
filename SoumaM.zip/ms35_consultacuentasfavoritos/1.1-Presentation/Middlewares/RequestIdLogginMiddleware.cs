﻿namespace Microservices.Middlewares
{
    public class RequestIdLogginMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestIdLogginMiddleware> _logger;
        private readonly string _headerName;

        public RequestIdLogginMiddleware(RequestDelegate next, ILogger<RequestIdLogginMiddleware> logger, string headerName = "FastServer-Request-Id")
        {
            _next = next;
            _logger = logger;
            _headerName = headerName;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Headers.TryGetValue("FastServer-Request-Id", out var requestId) && !string.IsNullOrEmpty(requestId))
            {
                using (_logger.BeginScope(new Dictionary<string, string>
                {
                    ["FastServer-Request-Id"] = requestId.ToString()
                }))
                {
                    await _next(context);
                }
            }
            else
            {
                using (_logger.BeginScope(new Dictionary<string, string>
                {
                    ["FastServer-Request-Id"] = Guid.Empty.ToString()
                }))
                {
                    await _next(context);
                }
            }
        }
    }
}
