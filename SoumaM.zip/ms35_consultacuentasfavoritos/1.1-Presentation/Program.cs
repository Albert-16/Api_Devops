using CoreWCF;
using ConfigLoader;
using Infraestructure;
using CoreWCF.Description;
using CoreWCF.Configuration;
using Microservices.Services;
using Microsoft.AspNetCore.Mvc;
using Fastserver.Logger.WebSocket;
using System.Runtime.Serialization;
using ConfigLoader.Extensions.DependencyInjection;
using JT400CS.Extensions;
using UtilesAndHelpers.Helpers;
using Microservices.Middlewares;

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddServiceModelServices()        // Habilita todos los servicios configurados.
    .AddServiceModelMetadata()        // Habilita el metadata del WSDL.
    .AddConfigLoader(options =>       // Habilita el entorno de configuraciones
    {
        options.SettingsFile = "app.json";
        options.ValidateSchema = true;
        options.OnConfigurationLoaded = config =>
        {
            Console.WriteLine($"-> Configuracion cargada: {config.Globals.ServiceName}.");
        };

        options.OnConfigurationError = ex =>
        {
            Console.WriteLine($"-> Error de configuraci�n: {ex.Message}.");
        };
    })
    .AddLogging(config =>             // Habilita el uso del ILogger 
    {
        config.ClearProviders();
        config.AddConsole();
        config.AddWebSocketLogger(options =>
        {
            AppConfig.Load();
            options.WebSocketUrl = AppConfig.Globals.MessageBroker.Url;
            options.Layer = string.Join("-", AppConfig.Globals.ServiceName, AppConfig.Globals.ServiceMethod);
            options.LogTopic = "microservice-logs";
            options.MinimumLogLevel = LogLevel.Debug;
            options.IncludeScopes = true;
            options.AutoReconnect = true;
            options.MaxReconnectAttempts = 0;
            options.MaxReconnectDelaySeconds = 30;
            options.EnableVerboseClientLogging = builder.Environment.IsDevelopment();
        });
        config.AddFilter<WebSocketLoggerProvider>("Microsoft.AspNetCore", LogLevel.Information);
    })
    .AddScoped<DoProcessService>()
    .AddHealthChecks();
builder.Services.AddJT400CS(options =>
{
    //Cargar Ambiente
    AppConfig.Load(AppConfig.Globals.DefaultAmbiente);
    options.Host = AppConfig.GetString("AS400Connection.Host");
    options.User = AppConfig.GetString("AS400Connection.User").DecodeBase64();
    options.Password = AppConfig.GetString("AS400Connection.Password").DecodeBase64();

    //Pool Connections Config
    options.UsePool = AppConfig.GetBool("UsePool");
    options.MaxConnections = AppConfig.GetInt("MaxConnections"); // maximo de conexiones
    options.MaxInactivityMs = AppConfig.GetInt("MaxInactivityMs"); //5 mintos  de inactividad.
    options.MaxLifetimeMs = AppConfig.GetInt("MaxLifeTimeMs"); //30 minutos la vida maxima de cada conexion.
    options.MaxUseCount = AppConfig.GetInt("MaxUseCount"); ; // usos maximos de conexion para su descarte evita la acumulacion de estados internos en el as400
});

builder.Services
    .AddInfraestructureServices();  //Integra los servicios necesarios de la capa de infraestructura

var app = builder.Build();

app.UseMiddleware<RequestIdLogginMiddleware>();
app.MapHealthChecks("/health");

app.UseServiceModel(builder =>
{
    builder.AddService<DoProcessService>();
    builder.AddServiceEndpoint<DoProcessService, IDoProcess>(new BasicHttpBinding(), "/DoProcess");

    var metadata = app.Services.GetRequiredService<ServiceMetadataBehavior>();
    metadata.HttpGetEnabled = true;
});

app.Run();