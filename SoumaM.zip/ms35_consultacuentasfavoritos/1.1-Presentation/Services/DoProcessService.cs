﻿using System.Runtime.InteropServices;
using ConfigLoader;
using CoreWCF;
using FastServer.Models;
using FastServer.Utiles.Linq;
using FastServer.Utiles.Security;
using FastServer.Utiles.Serialization;
using Infraestructure.Services;

namespace Microservices.Services
{
    public class DoProcessService : IDoProcess
    {
        private readonly ILogger<DoProcessService> _logger;
        private readonly IConfigManager _configManager;
        private readonly IRepository _repository;
        public DoProcessService(ILogger<DoProcessService> logger, IConfigManager configManager, IRepository repository)
        {
            _logger = logger;
            _configManager = configManager;
            _repository = repository;
        }

        public async Task<string> DoProcess(string dataTransferObject)
        {
            DataTransferObject responseData = new DataTransferObject()
            {
                Error = "00000000000000000000",
                ExternalError = "PROCESO REALIZADO CORRECTAMENTE",
                InternalError = "",
                ExecuteMethod = _configManager.Globals.ServiceMethod,
                Bank = _configManager.GetString("bank"),
                Data = new Data()
                {
                    DataList = new(),
                    Field = "RESPONSE"
                }
            };
            try
            {
                if (string.IsNullOrEmpty(dataTransferObject))
                {
                    responseData.Error = "10000000000000000001";
                    responseData.ExternalError = $"String XML enviado no tiene formato correcto de ${nameof(DataTransferObject)}.";
                    return responseData.ConvertToXML().EncryptText(_configManager.GetString("key"), 256);
                }

                var request = dataTransferObject.DecryptText(_configManager.GetString("key"), 256)
                    .ToDataTransferObject();

                if (request is null)
                {
                    responseData.Error = "10000000000000000002";
                    responseData.ExternalError = "El objeto desencriptado no tiene el formato correcto de un DTO.";
                    return responseData.ConvertToXML().EncryptText(_configManager.GetString("key"), 256);
                }

                if (request.ExecuteMethod.ToLower() != _configManager.Globals.ServiceMethod.ToLower())
                {
                    responseData.Error = "10000000000000000004";
                    responseData.ExternalError = $"La peticion {request.ExecuteMethod.ToLower()} no pertenece al microservicio.";
                    return responseData.ConvertToXML().EncryptText(_configManager.GetString("key"), 256);
                }

                var requestData = request?.SelectDataByName("REQUEST_DETAIL")?.FirstOrDefault();

                if (requestData is null)
                {
                    responseData.Error = "10000000000000000007";
                    responseData.ExternalError = "No se han encontrado los parametros necesarios para el request.";
                    return responseData.ConvertToXML().EncryptText(_configManager.GetString("key"), 256);
                }

                var requestId = request?.SelectDataByName("REQUEST_HEADER")?.FirstOrDefault()?.
                    DataList?.Where(x => x.Field == "TST_04_THREAD").FirstOrDefault()?.Value;

                if (requestId is null)
                {
                    responseData.Error = "10000000000000000007";
                    responseData.ExternalError = "No se han encontrado los parametros necesarios para el request.";
                    return responseData.ConvertToXML().EncryptText(_configManager.GetString("key"), 256);
                }

                if (requestId.StartsWith("ID")) //Peticiones que vienen de servibot Antiguo
                {
                    requestId = requestId.ToLower().Replace($"-{request.ExecuteMethod.ToLower()}", "")
                        .Replace("ID-", "");
                    requestId = string.Join("-", requestId.Split('-').Skip(2));
                }

                //logica de funcionamiento del servicio
                var response = await _repository.DoExecute(dataRequest: requestData, requestId: Guid.Parse(requestId));
                responseData.Data = response.Data;
                return responseData.ConvertToXML().EncryptText(_configManager.GetString("key"), 256);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error no controlado en DoProcess.");
                throw new FaultException(
                    new FaultReason($"Error interno del servicio: {ex.Message}"),
                    new FaultCode("Server"),
                    "DoProcess");
            }
        }
    }

}
