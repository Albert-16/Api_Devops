﻿using CoreWCF;
using FastServer.Models;

namespace Microservices.Services
{
    [ServiceContract(Namespace = $"http://{MS35_ConsultaCuentasFavoritosSolutionName}/")]
    public interface IDoProcess
    {
        private const string MS35_ConsultaCuentasFavoritosSolutionName = "MS35_ConsultaCuentasFavoritosSolution";

        [OperationContract(Action = $"http://{MS35_ConsultaCuentasFavoritosSolutionName}/DoProcess")]
        Task<string> DoProcess([MessageParameter(Name = nameof(DataTransferObject))] string dataTransferObject);
    }
}
