﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;

namespace DistributedServices
{
    public static partial class ServiceCollectionExtensions
    {
        public static IServiceCollection AddDistributedServices(this IServiceCollection services)
        {
            //Registrar los servicios de dependencia de la libreria
            return services;
        }
    }

}
