using JT400CS.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace Domain.Entities;

/// <summary>
/// Definición del programa CYB00035CL
/// Librería: CYBERPGM
/// </summary>
[Programs(library: "CYBERPGM", name: "CYB00035LC")]
public class CYB00035LC
{
    /// <summary>
    /// Parámetro de entrada/salida: nombreOperacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "nombreOperacion", parameterType: ParameterType.InputOutput, length: 100, Index = 1)]
    public string NombreOperacion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada/salida: total (Longitud: 100)
    /// </summary>
    [Parameter(name: "total", parameterType: ParameterType.InputOutput, length: 100, Index = 2)]
    public string Total { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: jornada (Longitud: 100)
    /// </summary>
    [Parameter(name: "jornada", parameterType: ParameterType.Input, length: 100, Index = 3)]
    public string Jornada { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: canal (Longitud: 100)
    /// </summary>
    [Parameter(name: "canal", parameterType: ParameterType.Input, length: 100, Index = 4)]
    public string Canal { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: modoDeOperacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "modoDeOperacion", parameterType: ParameterType.Input, length: 100, Index = 5)]
    public string ModoDeOperacion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: usuario (Longitud: 100)
    /// </summary>
    [Parameter(name: "usuario", parameterType: ParameterType.Input, length: 100, Index = 6)]
    public string Usuario { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: perfil (Longitud: 100)
    /// </summary>
    [Parameter(name: "perfil", parameterType: ParameterType.Input, length: 100, Index = 7)]
    public string Perfil { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: versionServicio (Longitud: 100)
    /// </summary>
    [Parameter(name: "versionServicio", parameterType: ParameterType.Input, length: 100, Index = 8)]
    public string VersionServicio { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada/salida: idTransaccion (Longitud: 100)
    /// </summary>
    [Parameter(name: "idTransaccion", parameterType: ParameterType.InputOutput, length: 100, Index = 9)]
    public string IdTransaccion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: idSesion (Longitud: 100)
    /// </summary>
    [Parameter(name: "idSesion", parameterType: ParameterType.Input, length: 100, Index = 10)]
    public string IdSesion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codIdioma (Longitud: 100)
    /// </summary>
    [Parameter(name: "codIdioma", parameterType: ParameterType.Input, length: 100, Index = 11)]
    public string CodIdioma { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valOrigen (Longitud: 100)
    /// </summary>
    [Parameter(name: "valOrigen", parameterType: ParameterType.Input, length: 100, Index = 12)]
    public string ValOrigen { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codPais (Longitud: 100)
    /// </summary>
    [Parameter(name: "codPais", parameterType: ParameterType.Input, length: 100, Index = 13)]
    public string CodPais { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valVersionApp (Longitud: 100)
    /// </summary>
    [Parameter(name: "valVersionApp", parameterType: ParameterType.Input, length: 100, Index = 14)]
    public string ValVersionApp { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: tipoIdentificacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoIdentificacion", parameterType: ParameterType.Input, length: 100, Index = 15)]
    public string TipoIdentificacion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: numeroIdentificacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "numeroIdentificacion", parameterType: ParameterType.Input, length: 100, Index = 16)]
    public string NumeroIdentificacion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada/salida: cantidadRegistros (Longitud: 100)
    /// </summary>
    [Parameter(name: "cantidadRegistros", parameterType: ParameterType.InputOutput, length: 100, Index = 17)]
    public string CantidadRegistros { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: estadoCuentaACH (Longitud: 100)
    /// </summary>
    [Parameter(name: "estadoCuentaACH", parameterType: ParameterType.Input, length: 100, Index = 18)]
    public string EstadoCuentaACH { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codigoBanco (Longitud: 100)
    /// </summary>
    [Parameter(name: "codigoBanco", parameterType: ParameterType.Input, length: 100, Index = 19)]
    public string CodigoBanco { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: cuentaACH (Longitud: 100)
    /// </summary>
    [Parameter(name: "cuentaACH", parameterType: ParameterType.Input, length: 100, Index = 20)]
    public string CuentaACH { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: tipoCuentaACH (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoCuentaACH", parameterType: ParameterType.Input, length: 100, Index = 21)]
    public string TipoCuentaACH { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codMoneda (Longitud: 100)
    /// </summary>
    [Parameter(name: "codMoneda", parameterType: ParameterType.Input, length: 100, Index = 22)]
    public string CodMoneda { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valNombreTitular (Longitud: 100)
    /// </summary>
    [Parameter(name: "valNombreTitular", parameterType: ParameterType.Input, length: 100, Index = 23)]
    public string ValNombreTitular { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valNumeroIdentificacionDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "valNumeroIdentificacionDestino", parameterType: ParameterType.Input, length: 100, Index = 24)]
    public string ValNumeroIdentificacionDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valCuentaDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "valCuentaDestino", parameterType: ParameterType.Input, length: 100, Index = 25)]
    public string ValCuentaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valAlias (Longitud: 100)
    /// </summary>
    [Parameter(name: "valAlias", parameterType: ParameterType.Input, length: 100, Index = 26)]
    public string ValAlias { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codTipoCuentaDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "codTipoCuentaDestino", parameterType: ParameterType.Input, length: 100, Index = 27)]
    public string CodTipoCuentaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codTipoTransaccion (Longitud: 100)
    /// </summary>
    [Parameter(name: "codTipoTransaccion", parameterType: ParameterType.Input, length: 100, Index = 28)]
    public string CodTipoTransaccion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: registroSiguiente (Longitud: 100)
    /// </summary>
    [Parameter(name: "registroSiguiente", parameterType: ParameterType.Input, length: 100, Index = 29)]
    public string RegistroSiguiente { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valNombre (Longitud: 100)
    /// </summary>
    [Parameter(name: "valNombre", parameterType: ParameterType.Input, length: 100, Index = 30)]
    public string ValNombre { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valValor (Longitud: 100)
    /// </summary>
    [Parameter(name: "valValor", parameterType: ParameterType.Input, length: 100, Index = 31)]
    public string ValValor { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de salida: caracterAceptacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "caracterAceptacion", parameterType: ParameterType.Output, length: 100, Index = 32)]
    public string? CaracterAceptacion { get; set; }

    /// <summary>
    /// Parámetro de salida: ultimoMensaje (Longitud: 100)
    /// </summary>
    [Parameter(name: "ultimoMensaje", parameterType: ParameterType.Output, length: 100, Index = 33)]
    public string? UltimoMensaje { get; set; }

    /// <summary>
    /// Parámetro de salida: codMsgRespuesta (Longitud: 100)
    /// </summary>
    [Parameter(name: "codMsgRespuesta", parameterType: ParameterType.Output, length: 100, Index = 34)]
    public string? CodMsgRespuesta { get; set; }

    /// <summary>
    /// Parámetro de salida: msgRespuesta (Longitud: 100)
    /// </summary>
    [Parameter(name: "msgRespuesta", parameterType: ParameterType.Output, length: 100, Index = 35)]
    public string? MsgRespuesta { get; set; }

    /// <summary>
    /// Parámetro de salida: valTalonRegistroAnterior (Longitud: 100)
    /// </summary>
    [Parameter(name: "valTalonRegistroAnterior", parameterType: ParameterType.Output, length: 100, Index = 36)]
    public string? ValTalonRegistroAnterior { get; set; }

    /// <summary>
    /// Parámetro de salida: archivoContinuacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "archivoContinuacion", parameterType: ParameterType.Output, length: 100, Index = 37)]
    public string? ArchivoContinuacion { get; set; }

    /// <summary>
    /// Parámetro de entrada: codigoDeBanco (Longitud: 100)
    /// </summary>
    [Parameter(name: "codigoDeBanco", parameterType: ParameterType.Input, length: 100, Index = 38)]
    public string CodigoDeBanco { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: tipoDeCuenta (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoDeCuenta", parameterType: ParameterType.Input, length: 100, Index = 39)]
    public string TipoDeCuenta { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codigoDeRuta (Longitud: 100)
    /// </summary>
    [Parameter(name: "codigoDeRuta", parameterType: ParameterType.Input, length: 100, Index = 40)]
    public string CodigoDeRuta { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: numeroDeCuenta (Longitud: 100)
    /// </summary>
    [Parameter(name: "numeroDeCuenta", parameterType: ParameterType.Input, length: 100, Index = 41)]
    public string NumeroDeCuenta { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: tipoDeIdentificacionCuenta (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoDeIdentificacionCuenta", parameterType: ParameterType.Input, length: 100, Index = 42)]
    public string TipoDeIdentificacionCuenta { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: numeroDeIdentificacionCuenta (Longitud: 100)
    /// </summary>
    [Parameter(name: "numeroDeIdentificacionCuenta", parameterType: ParameterType.Input, length: 100, Index = 43)]
    public string NumeroDeIdentificacionCuenta { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: nombreCliente (Longitud: 100)
    /// </summary>
    [Parameter(name: "nombreCliente", parameterType: ParameterType.Input, length: 100, Index = 44)]
    public string NombreCliente { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: alias (Longitud: 100)
    /// </summary>
    [Parameter(name: "alias", parameterType: ParameterType.Input, length: 100, Index = 45)]
    public string Alias { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valBancoDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "valBancoDestino", parameterType: ParameterType.Input, length: 100, Index = 46)]
    public string ValBancoDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: descripcion (Longitud: 100)
    /// </summary>
    [Parameter(name: "descripcion", parameterType: ParameterType.Input, length: 100, Index = 47)]
    public string Descripcion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: estado (Longitud: 100)
    /// </summary>
    [Parameter(name: "estado", parameterType: ParameterType.Input, length: 100, Index = 48)]
    public string Estado { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codigoRechazo (Longitud: 100)
    /// </summary>
    [Parameter(name: "codigoRechazo", parameterType: ParameterType.Input, length: 100, Index = 49)]
    public string CodigoRechazo { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valBanco (Longitud: 100)
    /// </summary>
    [Parameter(name: "valBanco", parameterType: ParameterType.Input, length: 100, Index = 50)]
    public string ValBanco { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valFechaHoraCreacion (Longitud: 100)
    /// </summary>
    [Parameter(name: "valFechaHoraCreacion", parameterType: ParameterType.Input, length: 100, Index = 51)]
    public string ValFechaHoraCreacion { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valCuentaOrigen (Longitud: 100)
    /// </summary>
    [Parameter(name: "valCuentaOrigen", parameterType: ParameterType.Input, length: 100, Index = 52)]
    public string ValCuentaOrigen { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: familia (Longitud: 100)
    /// </summary>
    [Parameter(name: "familia", parameterType: ParameterType.Input, length: 100, Index = 53)]
    public string Familia { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: tipoProducto (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoProducto", parameterType: ParameterType.Input, length: 100, Index = 54)]
    public string TipoProducto { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: grupoProducto (Longitud: 100)
    /// </summary>
    [Parameter(name: "grupoProducto", parameterType: ParameterType.Input, length: 100, Index = 55)]
    public string GrupoProducto { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codigoProducto (Longitud: 100)
    /// </summary>
    [Parameter(name: "codigoProducto", parameterType: ParameterType.Input, length: 100, Index = 56)]
    public string CodigoProducto { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: monedaOrigen (Longitud: 100)
    /// </summary>
    [Parameter(name: "monedaOrigen", parameterType: ParameterType.Input, length: 100, Index = 57)]
    public string MonedaOrigen { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: tipoCtaDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoCtaDestino", parameterType: ParameterType.Input, length: 100, Index = 58)]
    public string TipoCtaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: contEmails (Longitud: 100)
    /// </summary>
    [Parameter(name: "contEmails", parameterType: ParameterType.Input, length: 100, Index = 59)]
    public string ContEmails { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: contRegist (Longitud: 100)
    /// </summary>
    [Parameter(name: "contRegist", parameterType: ParameterType.Input, length: 100, Index = 60)]
    public string ContRegist { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: contRegDAVIVI (Longitud: 100)
    /// </summary>
    [Parameter(name: "contRegDAVIVI", parameterType: ParameterType.Input, length: 100, Index = 61)]
    public string ContRegDAVIVI { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: contRegSINPE (Longitud: 100)
    /// </summary>
    [Parameter(name: "contRegSINPE", parameterType: ParameterType.Input, length: 100, Index = 62)]
    public string ContRegSINPE { get; set; } = string.Empty;
}
