
using JT400CS.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace Domain.Entities;

/// <summary>
/// Definición del programa CYBI0060CL
/// Librería: CYBERPGM
/// </summary>
[Programs(library: "CYBERPGM", name: "CYBI0060CL")]
public class CYBI0060CL
{
    /// <summary>
    /// Parámetro de entrada: valCuentaOrigen (Longitud: 100)
    /// </summary>
    [Parameter(name: "valCuentaOrigen", parameterType: ParameterType.Input, length: 100, Index = 1)]
    public string ValCuentaOrigen { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: valCuentaDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "valCuentaDestino", parameterType: ParameterType.Input, length: 100, Index = 2)]
    public string ValCuentaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada: codTipoCuentaDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "codTipoCuentaDestino", parameterType: ParameterType.Input, length: 100, Index = 3)]
    public string CodTipoCuentaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de salida: familia (Longitud: 100)
    /// </summary>
    [Parameter(name: "familia", parameterType: ParameterType.Output, length: 100, Index = 4)]
    public string? Familia { get; set; }

    /// <summary>
    /// Parámetro de entrada/salida: tipoProducto (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoProducto", parameterType: ParameterType.InputOutput, length: 100, Index = 5)]
    public string TipoProducto { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de salida: grupoProducto (Longitud: 100)
    /// </summary>
    [Parameter(name: "grupoProducto", parameterType: ParameterType.Output, length: 100, Index = 6)]
    public string? GrupoProducto { get; set; }

    /// <summary>
    /// Parámetro de salida: codigoProducto (Longitud: 100)
    /// </summary>
    [Parameter(name: "codigoProducto", parameterType: ParameterType.Output, length: 100, Index = 7)]
    public string? CodigoProducto { get; set; }

    /// <summary>
    /// Parámetro de entrada: monedaOrigen (Longitud: 100)
    /// </summary>
    [Parameter(name: "monedaOrigen", parameterType: ParameterType.Input, length: 100, Index = 8)]
    public string MonedaOrigen { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada/salida: tipoCtaDestino (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoCtaDestino", parameterType: ParameterType.InputOutput, length: 100, Index = 9)]
    public string TipoCtaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Parámetro de entrada/salida: tipoCtaOrigen (Longitud: 100)
    /// </summary>
    [Parameter(name: "tipoCtaOrigen", parameterType: ParameterType.InputOutput, length: 100, Index = 10)]
    public string TipoCtaOrigen { get; set; } = string.Empty;
}
