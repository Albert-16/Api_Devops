﻿using LinqForge.Attributes;

namespace Domain.Models
{
    [Table("CYBFAV", Schema = "CYBERDTA")]
    public record CYBFAV
    {
        [Column("BCODES")]
        public string BancoDestino { get; set; }
        [Column("CODBCO")]
        public string CodigoBanco { get; set; }
        [Column("CODMOND")]
        public string ModenaDestino { get; set; }
        [Column("CODMONO")]
        public string MonedaOrigen { get; set; }
        [Column("CODTIPTRN")]
        public string CodTipoTransaccion { get; set; }
        [Column("FCHFAVCR")]
        public string FechaHoraCreacion { get; set; }
        [Column("GUIDCTFV")]
        public string IdentificadorUnico { get; set; }
        [Column("NOMTIT")]
        public string NombreTitular { get; set; }
        [Column("NUMCTAD")]
        public string NumeroCuentaDestino { get; set; }
        [Column("NUMCTAO")]
        public string NumeroCuentaOrigen { get; set; }
        [Column("NUMIDED")]
        public string NumeroIdentidadDestino { get; set; }
        [Column("NUMIDEO")]
        public string NumeroIdentidadOrigen { get; set; }
        [Column("TIPCTAFD")]
        public string TipoCuentaDestino { get; set; }
        [Column("TIPCTAFO")]
        public string TipoCuentaOrigen { get; set; }
        [Column("VALALIAS")]
        public string AliasCuenta { get; set; }
        [Column("VALEST")]
        public string ValEstado { get; set; }

    }
}