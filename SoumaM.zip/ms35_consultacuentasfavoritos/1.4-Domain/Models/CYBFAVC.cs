﻿using LinqForge.Attributes;

namespace Domain.Models
{
    [Table("CYBFAVC", Schema = "CYBERDTA")]
    public record CYBFAVC
    {
        [Column("CODBCO")]
        public string CodigoBanco { get; set; }

        [Column("CODMOND")]
        public string MonedaDestino { get; set; }

        [Column("CODMONO")]
        public string MonedaOrigen { get; set; }

        [Column("CODTIPTRN")]
        public string CodTipoTransaccion { get; set; }

        [Column("FAVMAIL")]
        public string Correo { get; set; }

        [Column("GUIDCOR")]
        public string IdentificadorUnico { get; set; }

        [Column("NUMCTAD")]
        public string NumeroCuentaDestino { get; set; }

        [Column("NUMCTAO")]
        public string NumeroCuentaOrigen { get; set; }

        [Column("NUMIDED")]
        public string NumeroIdentidadDestino { get; set; }

        [Column("NUMIDEO")]
        public string NumeroIdentidadOrigen { get; set; }

        [Column("TIPCTAFD")]
        public string TipoCuentaDestino { get; set; }

        [Column("TIPCTAFO")]
        public string TipoCuentaOrigen { get; set; }
    }
}