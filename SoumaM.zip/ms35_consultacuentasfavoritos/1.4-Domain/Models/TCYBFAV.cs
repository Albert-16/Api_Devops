﻿using LinqForge.Attributes;

namespace Domain.Models
{
    [Table("TCYBFAV", Schema = "CYBERDTA")]
    public class TCYBFAV
    {
        [Column("BCXDES")]
        public string BancoDestino { get; set; }
        [Column("COXBCO")]
        public string CodigoBanco { get; set; }
        [Column("COXMOND")]
        public string ModenaDestino { get; set; }
        [Column("COXMONO")]
        public string MonedaOrigen { get; set; }
        [Column("CTIPTRN")]
        public string CodTipoTransaccion { get; set; }
        [Column("FCXFAVCR")]
        public string FechaHoraCreacion { get; set; }
        [Column("GUIXCTFV")]
        public string IdentificadorUnico { get; set; }
        [Column("NOXTIT")]
        public string NombreTitular { get; set; }
        [Column("NUXCTAD")]
        public string NumeroCuentaDestino { get; set; }
        [Column("NUXCTAO")]
        public string NumeroCuentaOrigen { get; set; }
        [Column("NUXIDED")]
        public string NumeroIdentidadDestino { get; set; }
        [Column("NUXIDEO")]
        public string NumeroIdentidadOrigen { get; set; }
        [Column("TIXCTAFD")]
        public string TipoCuentaDestino { get; set; }
        [Column("TIXCTAFO")]
        public string TipoCuentaOrigen { get; set; }
        [Column("VALXEST")]
        public string ValEstado { get; set; }
        [Column("VAXALIAS")]
        public string AliasCuenta { get; set; }
    }
}