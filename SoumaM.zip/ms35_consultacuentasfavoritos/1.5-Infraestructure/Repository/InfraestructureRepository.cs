﻿using com.sun.corba.se.spi.orbutil.fsm;
using ConfigLoader;
using Dapper;
using DataMapper.Mappers;
using Domain.Entities;
using Domain.Models;
using FastServer.Models;
using Infraestructure.Services;
using JT400CS.Core;
using JT400CS.Extensions;
using LinqForge.Core;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using UtilesAndHelpers.Helper;
using UtilesAndHelpers.Helpers;

namespace Infraestructure.Repository
{
    public class InfraestructureRepository : IRepository
    {
        private readonly ILogger<InfraestructureRepository> _logger;
        private DataTransferObject dataResponse = new();
        private readonly IConfigManager _configManager;
        private readonly IJT400CSFactory _factory;

        public InfraestructureRepository(ILogger<InfraestructureRepository> logger, IConfigManager configManager, IJT400CSFactory factory)
        {
            _logger = logger;
            _configManager = configManager;
            _factory = factory;
        }

        public async Task<DataTransferObject> DoExecute(Data dataRequest, Guid requestId)
        {
            Stopwatch timerInicial = Stopwatch.StartNew();
            _logger.LogInformation("--> Inicio del Servicio--------------------------------------");
            CYB00035LC cyb00035lc = new CYB00035LC();
            cyb00035lc = ServiceDataMapper.MapFromRequest<CYB00035LC>(dataRequest);


            //Conexion al AS
            //-------------------------------------------------------------------------
            Stopwatch timer = Stopwatch.StartNew();
            _logger.LogInformation("Conexión JT400CS");
            using var jTComunication = _factory.Create();
            timer.Stop();
            _logger.LogInformation("Tiempo de Conexión: {1}", timer.ElapsedMilliseconds);


            //Call to AS --------------------------------------------------------------------------------------------------------
            _logger.LogInformation("--> StartConsult CYB00035LC CL");
            timer.Restart();

            _ = Task.Run(async () => {
                try
                {
                    await jTComunication.CallProgramAsync(cyb00035lc);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning("Falló el llamado de CYB00035CL | MENSAJE: {1}",ex.Message);
                }

            });

            timer.Stop();
            _logger.LogInformation("--> EndConsult CYB00035LC CL, Tiempo: {2}ms", timer.ElapsedMilliseconds);
            // ------------------------------------------------------------------------------------------------------------------


            // Seteo de Información
            var codTipoCuentaDestino = dataRequest.DataList.Where(x => x.Field == "codTipoCuentaDestino").SingleOrDefault()?.Value;
            var codTipoTransaccion = dataRequest.DataList.Where(x => x.Field == "codTipoTransaccion").SingleOrDefault()?.Value;

            // Generales
            var numeroIdentificacion = dataRequest.DataList.Where(x => x.Field == "numeroIdentificacion").SingleOrDefault()?.Value;
            var tipoIdentificacion = dataRequest.DataList.Where(x => x.Field == "tipoIdentificacion").SingleOrDefault()?.Value;
            var canal = dataRequest.DataList.Where(x => x.Field == "canal").SingleOrDefault()?.Value;

            // Datos de Filtro
            var cuentaACH = dataRequest.DataList.Where(x => x.Field == "cuentaACH").SingleOrDefault()?.Value;
            var valNombreTitular = dataRequest.DataList.Where(x => x.Field == "valNombreTitular").SingleOrDefault()?.Value;
            var valAlias = dataRequest.DataList.Where(x => x.Field == "valAlias").SingleOrDefault()?.Value;
            var valCuentaDestino = dataRequest.DataList.Where(x => x.Field == "valCuentaDestino").SingleOrDefault()?.Value;


            // Standard
            var modoDeOperacion = dataRequest.DataList.Where(x => x.Field == "modoDeOperacion").SingleOrDefault()?.Value;

            if (modoDeOperacion.Equals("2"))
            {
                // -- 1. Mapear tipo de cuenta --
                // ANTES: switch con 5 cases
                // AHORA: TipoCuentaMapper en UtilesAndHelpers (ya refactorizado)
                codTipoCuentaDestino = TipoCuentaMapper.Mapear(codTipoCuentaDestino);

                // -- 2. Construir y ejecutar query --
                // ANTES: ServiceQueryStringGenerator + From("CYBERDTA", "ITCYBFAV") + lógica TIXCTAFO/TIXCTAFD
                // AHORA: QueryBuilder<TCYBFAV> directo, DB2 elige el índice
                var db2Options = new QueryBuilderOptions
                {
                    Dialect = SqlDialect.Db2,
                    Library = "CYBERDTA",
                    TrimStrings = true,
                };

                var queryAs = BuildQueryModo2(db2Options, numeroIdentificacion, codTipoCuentaDestino).Build();
                var registrosQueryResult = new List<TCYBFAV>();
                try
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    var database = new OdbcConnection($"Driver={{{_configManager.GetString("AS400ODBC.driver")}}};System={_configManager.GetString("AS400ODBC.server")};Uid={Decrypt(_configManager.GetString("AS400ODBC.user").ToString())};Pwd={Decrypt(_configManager.GetString("AS400ODBC.password").ToString())};Port={_configManager.GetString("AS400ODBC.port")};");
                    _logger.LogInformation("--> Intentando abrir la conexión ODBC");
                    await database.OpenAsync();
                    sw.Stop();
                    _logger.LogInformation("--> Duracion de la conexion a la base de datos {Elapsed}ms", sw.Elapsed.TotalMilliseconds);

                    sw.Restart();
                    _logger.LogInformation("--> StartConsult TCYBFAV ");
                    registrosQueryResult = (await database.QueryAsync<TCYBFAV>(queryAs.Sql, queryAs.ToDapperParameters())).ToList();
                    sw.Stop();
                    _logger.LogInformation("--> EndConsult TCYBFAV {Elapsed}ms", sw.Elapsed.TotalMilliseconds);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"--> Error de comunicación {1}", ex.Message);
                }


                // -- 3. Validación temprana --
                // ANTES: if (!registrosQueryResult.Count.Equals(0)) { ... } else { setear error }
                //        (to-do José León: invertir el if para flujo limpio)
                // AHORA: se valida primero, si está vacío retorna error y sale
                if (!registrosQueryResult.Any())
                {
                    cyb00035lc.CodMsgRespuesta = "180306";
                    cyb00035lc.MsgRespuesta = "No posee productos inscritos para esta funcionalidad";
                    cyb00035lc.CaracterAceptacion = "M";

                    dataResponse = ServiceDataMapper.MapToResponse(cyb00035lc);
                    return dataResponse;
                }

                // -- 4. Paginación --
                // ANTES: contadores manuales i >= inicio && i <= final dentro del foreach
                // AHORA: Skip/Take. Tamaño de página 255 (así estaba en el código original)
                var archivoContinuacion = string.IsNullOrWhiteSpace(cyb00035lc.RegistroSiguiente)
                    ? 0
                    : int.Parse(cyb00035lc.RegistroSiguiente);

                const int sizePage = 255;
                var totalRegistros = registrosQueryResult.Count;

                var registrosPaginados = registrosQueryResult
                    .Skip(archivoContinuacion)
                    .Take(sizePage)
                    .ToList();

                // Cálculo de valores de paginación para la respuesta
                if (archivoContinuacion == 0)
                {
                    cyb00035lc.ArchivoContinuacion = totalRegistros > sizePage
                        ? (sizePage + 1).ToString()
                        : "0";
                    cyb00035lc.ValTalonRegistroAnterior = "0";
                    cyb00035lc.CantidadRegistros = totalRegistros.ToString();
                }
                else
                {
                    var registrosRestantes = totalRegistros - archivoContinuacion;
                    cyb00035lc.CantidadRegistros = registrosRestantes.ToString();

                    if (registrosRestantes > sizePage)
                    {
                        cyb00035lc.ValTalonRegistroAnterior = archivoContinuacion.ToString();
                        cyb00035lc.ArchivoContinuacion = (archivoContinuacion + sizePage).ToString();
                    }
                    else
                    {
                        cyb00035lc.ArchivoContinuacion = "0";
                        var talonAnterior = (archivoContinuacion - sizePage) <= 1
                            ? 0
                            : (archivoContinuacion - sizePage);
                        cyb00035lc.ValTalonRegistroAnterior = talonAnterior.ToString();
                    }
                }

                // -- 5. Mapear a estructura Data --
                // ANTES: foreach con diccionarios ProductosGS/ProductosTP + PropiedadesAdicionales
                // AHORA: MapearRegistrosModo2() que accede directo a las propiedades de TCYBFAV
                var registros = MapearRegistrosModo2(registrosPaginados, archivoContinuacion);

                dataResponse = ServiceDataMapper.MapToResponse(cyb00035lc);
                dataResponse.Data.DataList.Add(registros);
            }
            else
            {
                if (codTipoCuentaDestino == "S" && codTipoTransaccion == "C")
                {
                    _logger.LogInformation("--> SubModulo Destinos Autorizados -- Funcionalidad.");
                    _logger.LogInformation("--> Usuario: {1} | Cuenta: {2}",cyb00035lc.NumeroIdentificacion,cyb00035lc.NumeroDeCuenta);

                }
                else
                {
                    // Opciones de LinqForge
                    var db2Options = new QueryBuilderOptions
                    {
                        Dialect = SqlDialect.Db2,
                        Library = "CYBERDTA",
                        TrimStrings = true,
                    };

                    // -- Query con filtros dinámicos --
                    // Reemplaza: el array de 16 tablas IFAV1-IFAV16, 
                    //            el QueryMaker de 16 escenarios,
                    //            y el bug del queryAs sin else
                    var queryAs = BuildQuery(db2Options, numeroIdentificacion, codTipoCuentaDestino, valNombreTitular, valAlias, valCuentaDestino, cuentaACH)
                        .Build();

                    try
                    {
                        //Conexion al AS ODBC ------------------------------------------------------------------------------------------------
                        Stopwatch sw = Stopwatch.StartNew();
                        var database = new OdbcConnection($"Driver={{{_configManager.GetString("AS400ODBC.driver")}}};System={_configManager.GetString("AS400ODBC.server")};Uid={Decrypt(_configManager.GetString("AS400ODBC.user").ToString())};Pwd={Decrypt(_configManager.GetString("AS400ODBC.password").ToString())};Port={_configManager.GetString("AS400ODBC.port")};");
                        _logger.LogInformation("--> Intentando abrir la conexión ODBC");
                        await database.OpenAsync();
                        sw.Stop();
                        _logger.LogInformation($"--> Tiempo para conectar a la base de datos {sw.Elapsed.TotalMilliseconds}ms");
                        // -------------------------------------------------------------------------------------------------------------------

                        //Llamado al AS
                        var responseConsult = await database.QueryAsync<CYBFAV>(queryAs.Sql, queryAs.ToDapperParameters());

                        //Mapeamos la respuesta (Optimizado)
                        if (canal == "4")
                        {
                            var formato = "dd/MM/yyyy'T'HH:mm:sszzz";
                            responseConsult = responseConsult
                                .Select(item => item with
                                {
                                    TipoCuentaDestino = MapearTipoCuentaCanal4(item.TipoCuentaDestino)
                                })
                                .GroupBy(item => new { item.NumeroCuentaDestino, item.NumeroIdentidadOrigen })
                                .Select(grupo => grupo
                                .OrderByDescending(item => DateTime.TryParseExact(item.FechaHoraCreacion?.Trim(), formato, CultureInfo.InvariantCulture, DateTimeStyles.None, out var fecha) ? fecha:DateTime.MinValue)
                                .First())
                                .ToList();
                        }

                        // -- 1. Consultar correos asociados --
                        // ANTES: SelectAll + From("CYBERDTA", "ICYBFAVC03") + EasyCrudDataModels.SelectExecute
                        // AHORA: QueryBuilder<CYBFAVC> + Dapper async (misma tabla, sin índice específico)
                        var queryCorreos = new QueryBuilder<CYBFAVC>(db2Options)
                            .Select()
                            .Where(item => item.NumeroIdentidadOrigen == numeroIdentificacion)
                            .Build();


                        sw.Restart();
                        _logger.LogInformation("--> StartConsult CYBFAVC");
                        var correos = await database.QueryAsync<CYBFAVC>(
                            queryCorreos.Sql,
                            queryCorreos.ToDapperParameters());
                        sw.Stop();
                        _logger.LogInformation("--> EndConsult CYBFAVC {Elapsed}ms", sw.Elapsed.TotalMilliseconds);

                        // ANTES: en MapData, por cada registro se hacía:
                        //   temp = (from item1 in temp where item1.GetValue("GUIDCOR") == gid1 select item1).ToList()
                        //   Eso recorría TODOS los correos por cada registro.
                        // AHORA: se pre-agrupan en Dictionary por GUID.
                        var correosPorGuid = correos
                            .GroupBy(c => c.IdentificadorUnico)
                            .ToDictionary(g => g.Key, g => g.ToList());

                        // -- 2. Filtrar por tipo de producto --
                        // ANTES: dentro de MapData → if (codTipoCuentaDestino == "T" || codTipoCuentaDestino == item.GetValue("CODTIPTRN"))
                        // AHORA: se filtra antes de mapear, separando responsabilidades
                        var registrosFiltrados = responseConsult
                            .Where(item => codTipoCuentaDestino == "T"
                                        || codTipoCuentaDestino == item.CodTipoTransaccion)
                            .ToList();

                        // -- 3. Validación temprana --
                        // ANTES: se mapeaba TODO con MapData, después se buscaba si el tag "Registro" existía
                        //        en tags.DataList, y si era null seteaba el error.
                        //        (to-do de José León: "esta validación no es necesario que se compruebe de esta forma")
                        // AHORA: se valida directo sobre la lista filtrada. Si está vacía, no hay razón para mapear.
                        if (!registrosFiltrados.Any())
                        {
                            cyb00035lc.CodMsgRespuesta = "180306";
                            cyb00035lc.MsgRespuesta = "No posee productos inscritos para esta funcionalidad";
                            cyb00035lc.CaracterAceptacion = "M";

                            dataResponse = ServiceDataMapper.MapToResponse(cyb00035lc);
                            return dataResponse;
                        }
                        else
                        {
                            cyb00035lc.CodMsgRespuesta = "0";
                            cyb00035lc.MsgRespuesta = "Successful";
                            cyb00035lc.CaracterAceptacion = "B";
                            cyb00035lc.UltimoMensaje = "Successful";
                        }

                            // -- 4. Paginación --
                            // ANTES: variable archivoContinuacion parseada con múltiples ifs, contadores manuales
                            //        index++, if (index >= contador && index <= contaFinal) dentro del foreach
                            // AHORA: Skip/Take sobre la lista ya filtrada. Misma lógica de página de 250.
                            var archivoContinuacion = string.IsNullOrWhiteSpace(cyb00035lc.RegistroSiguiente)
                                ? 0
                                : int.Parse(cyb00035lc.RegistroSiguiente);

                        const int pageSize = 250;
                        var totalRegistros = registrosFiltrados.Count;

                        // Skip salta los registros ya vistos, Take toma solo 250
                        var registrosPaginados = registrosFiltrados
                            .Skip(archivoContinuacion)
                            .Take(pageSize)
                            .ToList();

                        // Cálculo de paginación para la respuesta
                        // ANTES: bloques if/else con archivoContinuacion string, ParseInt, SetValue
                        // AHORA: misma lógica pero con acceso directo a propiedades
                        if (archivoContinuacion == 0)
                        {
                            cyb00035lc.ArchivoContinuacion = totalRegistros > pageSize
                                ? (pageSize + 1).ToString()
                                : "0";
                            cyb00035lc.ValTalonRegistroAnterior = "0";
                            cyb00035lc.CantidadRegistros = totalRegistros.ToString();
                        }
                        else
                        {
                            var registrosRestantes = totalRegistros - archivoContinuacion;
                            cyb00035lc.CantidadRegistros = registrosRestantes.ToString();

                            if (registrosRestantes > pageSize)
                            {
                                cyb00035lc.ValTalonRegistroAnterior = archivoContinuacion.ToString();
                                cyb00035lc.ArchivoContinuacion = (archivoContinuacion + pageSize).ToString();
                            }
                            else
                            {
                                cyb00035lc.ArchivoContinuacion = "0";
                                var talonAnterior = (archivoContinuacion - pageSize) <= 1
                                    ? 0
                                    : (archivoContinuacion - pageSize);
                                cyb00035lc.ValTalonRegistroAnterior = talonAnterior.ToString();
                            }
                        }

                        // -- 5. Mapear a estructura Data --
                        // ANTES: nameTagMapper.MapData(response, TableDictionaries.CybFavDictionary(), "Registro", ...)
                        //        El Mapper de Sunip instanciaba CYBI0060CL, recorría con foreach,
                        //        usaba GetValue/SetValue, y mezclaba filtrado + paginación + mapeo
                        // AHORA: MapearRegistros() solo mapea. El filtrado y paginación ya se hicieron arriba.
                        var tags = MapearRegistros(registrosPaginados, correosPorGuid, archivoContinuacion);

                        dataResponse = ServiceDataMapper.MapToResponse(cyb00035lc);
                        dataResponse.Data.DataList.Add(tags);

                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("--> Error Inesperado de Conexion o Consulta | Detail: {1}",ex.Message);
                    }


                }
            }
            timerInicial.Stop();
            _logger.LogInformation("--> Tiempo de Ejecucion del Servicio: {1}ms", timerInicial.ElapsedMilliseconds);
            _logger.LogInformation("--> Fin del Servicio------------------------------------------");
            return dataResponse;
        }
        private string Decrypt(string value)
        {
            byte[] bytes = Convert.FromBase64String(value);
            return Encoding.UTF8.GetString(bytes);
        }

        /// <summary>
        /// Construye la query de favoritos con filtros dinámicos.
        /// Reemplaza el QueryMaker de 16 escenarios y las 16 tablas IFAV.
        /// </summary>
        private QueryBuilder<CYBFAV> BuildQuery(
            QueryBuilderOptions db2Options,
            string numeroIdentificacion,
            string codTipoCuentaDestino,
            string? nombreTitular,
            string? alias,
            string? cuentaDestino,
            string? cuentaACH)
        {
            var query = new QueryBuilder<CYBFAV>(db2Options)
                .Select()
               .Where(item => item.NumeroIdentidadOrigen == numeroIdentificacion);

            //Excluir registros sin banco asignado (data inválida)
            query = query.Where(item => item.BancoDestino != "");

            // Filtro por tipo de cuenta (solo si no es "A" = todos)
            //if (!codTipoCuentaDestino.Equals("A") && !codTipoCuentaDestino.Equals("T"))
            //    query = query.Where(item => item.TipoCuentaDestino == codTipoCuentaDestino);

            // Filtros opcionales — cada uno se agrega solo si tiene valor
            if (!string.IsNullOrWhiteSpace(nombreTitular))
                query = query.Where(item => item.NombreTitular.Contains(nombreTitular));

            if (!string.IsNullOrWhiteSpace(alias))
                query = query.Where(item => item.AliasCuenta.Contains(alias));

            if (!string.IsNullOrWhiteSpace(cuentaDestino))
                query = query.Where(item => item.NumeroCuentaDestino.Contains(cuentaDestino));

            if (!string.IsNullOrWhiteSpace(cuentaACH))
                query = query.Where(item => item.NumeroCuentaOrigen.Contains(cuentaACH));

            return query.OrderByDescending(item => item.TipoCuentaDestino);
        }

        private static string MapearTipoCuentaCanal4(string tipo) => tipo switch
        {

            "CU" => "1",
            "PR" => "3",
            "TA" => "4",
            _ => tipo,
        };

        /// <summary>
        /// Mapea registros CYBFAV a la estructura Data/DataList que el consumidor espera en XML.
        /// 
        /// REEMPLAZA: MapData() del Mapper de Sunip.
        /// CAMBIOS CLAVE:
        /// - Ya no recibe EasyMappingTool, recibe CYBFAV directamente
        /// - Ya no filtra ni pagina (eso se hace antes de llamar este método)
        /// - Ya no usa ref int cant (el conteo se obtiene de registrosFiltrados.Count)
        /// - Ya no instancia CYBI0060CL ni PropiedadesAdicionales como clase
        /// - Los correos se buscan por Dictionary en vez de LINQ sobre lista completa
        /// </summary>
        private static Data MapearRegistros(
           List<CYBFAV> registros,
           Dictionary<string, List<CYBFAVC>> correosPorGuid,
           int inicioIndex)
        {
            var lista = new Data
            {
                HasData = true,
                Field = "Registros",
                DataList = new List<Data>()
            };

            for (int i = 0; i < registros.Count; i++)
            {
                var item = registros[i];
                var index = inicioIndex + i + 1;

                var registro = new Data
                {
                    HasData = true,
                    Field = "Registro",
                    DataList = new List<Data>()
                };

                // -- Campos principales --
                // ANTES: CrearParametros.GetData("campo", item.GetValue("COLUMNA"), true)
                // AHORA: new Data { } con acceso directo a la propiedad del record CYBFAV

                var codigoDeBanco = new Data { HasData = true, Field = "codigoDeBanco", Value = item.CodigoBanco?.Trim() };
                var numeroDeCuenta = new Data { HasData = true, Field = "numeroDeCuenta", Value = item.NumeroCuentaDestino?.Trim() };
                var valBancoDestino = new Data { HasData = true, Field = "valBancoDestino", Value = item.BancoDestino?.Trim() };
                var descripcion = new Data { HasData = true, Field = "descripcion", Value = item.ValEstado?.Trim() };
                var valFechaHoraCreacion = new Data { HasData = true, Field = "valFechaHoraCreacion", Value = item.FechaHoraCreacion?.Trim() };
                var codMoneda = new Data { HasData = true, Field = "codMoneda", Value = item.ModenaDestino?.Trim() };
                var alias = new Data { HasData = true, Field = "alias", Value = item.AliasCuenta?.Trim() };
                var nombreCliente = new Data { HasData = true, Field = "nombreCliente", Value = item.NombreTitular?.Trim() };
                var numIdentificacionCuenta = new Data { HasData = true, Field = "numeroDeIdentificacionCuenta", Value = item.NumeroIdentidadDestino?.Trim() };
                var valCuentaOrigen = new Data { HasData = true, Field = "valCuentaOrigen", Value = item.NumeroCuentaOrigen?.Trim() };
                var codTipoTransaccion = new Data { HasData = true, Field = "codTipoTransaccion", Value = item.CodTipoTransaccion?.Trim() };
                var guid = new Data { HasData = true, Field = "guid", Value = item.IdentificadorUnico?.Trim() };
                var tipoCtaDestino = new Data { HasData = true, Field = "tipoCtaDestino", Value = item.TipoCuentaDestino?.Trim() };
                var tipoCtaOrigen = new Data { HasData = true, Field = "tipoCtaOrigen", Value = item.TipoCuentaOrigen?.Trim() };
                var monedaOrigen = new Data { HasData = true, Field = "monedaOrigen", Value = item.MonedaOrigen?.Trim() };

                registro.DataList.Add(codigoDeBanco);
                registro.DataList.Add(numeroDeCuenta);
                registro.DataList.Add(valBancoDestino);
                registro.DataList.Add(descripcion);
                registro.DataList.Add(valFechaHoraCreacion);
                registro.DataList.Add(codMoneda);
                registro.DataList.Add(alias);
                registro.DataList.Add(nombreCliente);
                registro.DataList.Add(numIdentificacionCuenta);
                registro.DataList.Add(valCuentaOrigen);
                registro.DataList.Add(codTipoTransaccion);
                registro.DataList.Add(guid);
                registro.DataList.Add(tipoCtaDestino);
                registro.DataList.Add(tipoCtaOrigen);
                registro.DataList.Add(monedaOrigen);

                // -- Correos asociados --
                // ANTES: temp = (from item1 in temp where item1.GetValue("GUIDCOR") == gid1 ...)
                //        foreach sobre temp creando Data con GetValue("FAVMAIL")
                // AHORA: lookup O(1) en Dictionary pre-agrupado
                registro.DataList.Add(MapearCorreos(item.IdentificadorUnico, correosPorGuid));

                // -- Propiedades adicionales --
                // ANTES: new PropiedadesAdicionales(cybi0060cl).GetProps2(item)
                //        Instanciaba CYBI0060CL, usaba GetValue sobre EasyMappingTool
                // AHORA: método estático que recibe CYBFAV directamente
                registro.DataList.Add(GenerarPropiedadesAdicionales(item));

                lista.DataList.Add(registro);
            }

            return lista;
        }

        /// <summary>
        /// Busca correos por GUID y los mapea a estructura Data para el XML.
        /// 
        /// REEMPLAZA: el bloque dentro de MapData que hacía:
        ///   temp = (from item1 in temp where item1.GetValue("GUIDCOR") == gid1 select item1).ToList();
        ///   foreach (EasyMappingTool cor in temp) { ... cor.GetValue("FAVMAIL") ... }
        ///
        /// MEJORA: usa Dictionary.TryGetValue O(1) en vez de filtrar lista completa O(n) por registro.
        /// </summary>
        private static Data MapearCorreos(
            string guid,
            Dictionary<string, List<CYBFAVC>> correosPorGuid)
        {
            var emails = new Data
            {
                HasData = true,
                Field = "Emails",
                DataList = new List<Data>()
            };

            if (correosPorGuid.TryGetValue(guid, out var correosDelRegistro))
            {
                foreach (var correo in correosDelRegistro)
                {
                    var valEmail = new Data
                    {
                        HasData = true,
                        Field = "valEmail",
                        Value = correo.Correo
                    };

                    var email = new Data
                    {
                        HasData = true,
                        Field = "Email",
                        DataList = new List<Data> { valEmail }
                    };

                    emails.DataList.Add(email);
                }
            }

            return emails;
        }

        /// <summary>
        /// Construye la query para ModoDeOperacion 2.
        /// Consulta tabla TCYBFAV con filtro condicional por tipo de cuenta.
        ///
        /// REEMPLAZA: ServiceQueryStringGenerator + From("CYBERDTA", "ITCYBFAV")
        /// CAMBIO CLAVE: el campo dinámico TIXCTAFO/TIXCTAFD se resuelve aquí.
        /// - Si es seguro ("G") → filtra por TipoCuentaOrigen (TIXCTAFO)
        /// - Si es otro tipo → filtra por TipoCuentaDestino (TIXCTAFD)
        /// - Si es "A" (todos) → no filtra por tipo
        /// </summary>
        private QueryBuilder<TCYBFAV> BuildQueryModo2(
            QueryBuilderOptions db2Options,
            string numeroIdentificacion,
            string codTipoCuentaDestino)
        {
            var query = new QueryBuilder<TCYBFAV>(db2Options)
                .Select()
                .Where(item => item.NumeroIdentidadOrigen == numeroIdentificacion);

            // ANTES: string tipo = codTipoCuentaDestino == "G" ? "TIXCTAFO" : "TIXCTAFD"
            //        if (!codTipoCuentaDestino.Equals("A")) { WhereAnd(TIXCTAFD, "=") }
            // AHORA: misma lógica pero con propiedades tipadas
            if (codTipoCuentaDestino != "A")
            {
                if (codTipoCuentaDestino == "G")
                    query = query.Where(item => item.TipoCuentaOrigen == codTipoCuentaDestino);
                else
                    query = query.Where(item => item.TipoCuentaDestino == codTipoCuentaDestino);
            }

            return query.OrderByDescending(item => item.TipoCuentaDestino);
        }

        /// <summary>
        /// Mapea registros TCYBFAV a la estructura Data/DataList.
        /// Maneja dos variantes: seguros (TipoCuentaOrigen == "G") y productos normales.
        ///
        /// REEMPLAZA: el foreach con diccionarios ProductosGS/ProductosTP del código viejo.
        /// ANTES: por cada registro se elegía un diccionario, se recorría con foreach
        ///        para mapear campo AS400 → nombre XML, y se usaba un switch para setear CYBI0060CL.
        /// AHORA: acceso directo a propiedades de TCYBFAV. Sin diccionarios, sin CYBI0060CL.
        ///
        /// Los campos de ProductosGS y ProductosTP son los mismos pero en orden diferente.
        /// Ambos mapean a los mismos campos XML de salida.
        /// </summary>
        private static Data MapearRegistrosModo2(
            List<TCYBFAV> registros,
            int inicioIndex)
        {
            var lista = new Data
            {
                HasData = true,
                Field = "Registros",
                DataList = new List<Data>()
            };

            for (int i = 0; i < registros.Count; i++)
            {
                var item = registros[i];
                var index = inicioIndex + i + 1;
                var esSeguro = item.TipoCuentaOrigen?.Trim() == "G";

                var registro = new Data
                {
                    HasData = true,
                    Field = "Registro",
                    DataList = new List<Data>()
                };

                // ── Campos principales ──
                // ANTES: foreach sobre diccionario ProductosGS o ProductosTP
                //        registro.DataList.Add(CrearParametros.GetData(field.Trim(), value.Trim()))
                // AHORA: acceso directo a propiedades. Ambos diccionarios mapeaban los mismos
                //        campos XML, solo variaba el orden y los nombres de columna AS400.
                //        Con TCYBFAV y LinqForge, las propiedades ya tienen nombres legibles.

                var codigoDeBanco = new Data { HasData = true, Field = "codigoDeBanco", Value = item.CodigoBanco?.Trim() };
                var numeroDeCuenta = new Data { HasData = true, Field = "numeroDeCuenta", Value = item.NumeroCuentaDestino?.Trim() };
                var valBancoDestino = new Data { HasData = true, Field = "valBancoDestino", Value = item.BancoDestino?.Trim() };
                var descripcion = new Data { HasData = true, Field = "descripcion", Value = item.ValEstado?.Trim() };
                var valFechaHoraCreacion = new Data { HasData = true, Field = "valFechaHoraCreacion", Value = item.FechaHoraCreacion?.Trim() };
                var codMoneda = new Data { HasData = true, Field = "codMoneda", Value = item.ModenaDestino?.Trim() };
                var alias = new Data { HasData = true, Field = "alias", Value = item.AliasCuenta?.Trim() };
                var nombreCliente = new Data { HasData = true, Field = "nombreCliente", Value = item.NombreTitular?.Trim() };
                var numIdentificacionCuenta = new Data { HasData = true, Field = "numeroDeIdentificacionCuenta", Value = item.NumeroIdentidadDestino?.Trim() };
                var valCuentaOrigen = new Data { HasData = true, Field = "valCuentaOrigen", Value = item.NumeroCuentaOrigen?.Trim() };
                var codTipoTransaccion = new Data { HasData = true, Field = "codTipoTransaccion", Value = item.CodTipoTransaccion?.Trim() };
                var guid = new Data { HasData = true, Field = "guid", Value = item.IdentificadorUnico?.Trim() };
                var tipoCtaDestino = new Data { HasData = true, Field = "tipoCtaDestino", Value = item.TipoCuentaDestino?.Trim() };
                var tipoCtaOrigen = new Data { HasData = true, Field = "tipoCtaOrigen", Value = item.TipoCuentaOrigen?.Trim() };
                var monedaOrigen = new Data { HasData = true, Field = "monedaOrigen", Value = item.MonedaOrigen?.Trim() };

                registro.DataList.Add(codigoDeBanco);
                registro.DataList.Add(numeroDeCuenta);
                registro.DataList.Add(valBancoDestino);
                registro.DataList.Add(descripcion);
                registro.DataList.Add(valFechaHoraCreacion);
                registro.DataList.Add(codMoneda);
                registro.DataList.Add(alias);
                registro.DataList.Add(nombreCliente);
                registro.DataList.Add(numIdentificacionCuenta);
                registro.DataList.Add(valCuentaOrigen);
                registro.DataList.Add(codTipoTransaccion);
                registro.DataList.Add(guid);
                registro.DataList.Add(tipoCtaDestino);
                registro.DataList.Add(tipoCtaOrigen);
                registro.DataList.Add(monedaOrigen);

                // ── Propiedades adicionales ──
                // ANTES: if (seguro == "G") { AdicionalesSeguros() } else { GetProps() }
                // AHORA: dos métodos separados según tipo de producto
                if (esSeguro)
                    registro.DataList.Add(GenerarPropiedadesSeguros(item));
                else
                    registro.DataList.Add(GenerarPropiedadesProducto(item));

                lista.DataList.Add(registro);
            }

            return lista;
        }


        /// <summary>
        /// Genera PropiedadesAdicionales para productos de seguros ("G").
        ///
        /// REEMPLAZA: PropiedadesAdicionales(registro).AdicionalesSeguros()
        /// ANTES: recibía EasyMappingTool, usaba GetValue("TIXCTAFD"), GetValue("NUXCTAD"), etc.
        /// AHORA: accede directo a propiedades de TCYBFAV.
        /// </summary>
        private static Data GenerarPropiedadesSeguros(TCYBFAV item)
        {
            var props = new Data
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };

            props.DataList.Add(GenProp("tipo seguro", item.TipoCuentaDestino?.Trim()));
            props.DataList.Add(GenProp("POLIZA", item.NumeroCuentaDestino?.Trim()));
            props.DataList.Add(GenProp("Expediente", item.CodigoBanco?.Trim()));
            props.DataList.Add(GenProp("valCuentaOrigen", item.NumeroCuentaOrigen?.Trim()));
            props.DataList.Add(GenProp("monedaOrigen", item.MonedaOrigen?.Trim()));
            props.DataList.Add(GenProp("tipoProducto", item.TipoCuentaDestino?.Trim()));

            return props;
        }


        /// <summary>
        /// Genera PropiedadesAdicionales para productos normales (no seguros).
        ///
        /// REEMPLAZA: PropiedadesAdicionales(cybi0060cl).GetProps()
        /// ANTES: instanciaba CYBI0060CL, seteaba valores con switch dentro del foreach
        ///        del diccionario, luego llamaba GetProps() que leía de CYBI0060CL.
        /// AHORA: lee directo de TCYBFAV. El switch + CYBI0060CL eran un intermediario
        ///        innecesario — los valores vienen del mismo registro.
        ///
        /// El mapeo de familia/grupo es el mismo que en el bloque else (CYBFAV):
        /// "1" → CTA01, "6" → CTA02, otro → CTA03
        /// </summary>
        private static Data GenerarPropiedadesProducto(TCYBFAV item)
        {
            var props = new Data
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };

            props.DataList.Add(GenProp("valCuentaOrigen", item.NumeroCuentaOrigen?.Trim()));

            var tipoCuenta = item.TipoCuentaDestino?.Trim();
            var (grupo, codigoProducto) = tipoCuenta switch
            {
                "1" => ("CTA01", "1"),
                "6" => ("CTA02", "6"),
                _ => ("CTA03", tipoCuenta ?? "")
            };

            props.DataList.Add(GenProp("familia", "CTAS"));
            props.DataList.Add(GenProp("grupo", grupo));
            props.DataList.Add(GenProp("codigoProducto", codigoProducto));
            props.DataList.Add(GenProp("monedaOrigen", item.MonedaOrigen?.Trim()));
            props.DataList.Add(GenProp("tipoCtaDestino", item.CodTipoTransaccion?.Trim()));
            props.DataList.Add(GenProp("tipoProductoDestino", item.TipoCuentaDestino?.Trim()));
            props.DataList.Add(GenProp("tipoCtaOrigen", item.TipoCuentaOrigen?.Trim()));

            return props;
        }
        /// <summary>
        /// Genera el nodo PropiedadesAdicionales para cada registro en el XML.
        ///
        /// REEMPLAZA: clase PropiedadesAdicionales completa + método GetProps2().
        /// ANTES: instanciaba PropiedadesAdicionales con CYBI0060CL, llamaba GetProps2(EasyMappingTool)
        ///        que usaba item.GetValue("TIPCTAFD"), item.GetValue("NUMCTAO"), etc.
        /// AHORA: método estático que accede directo a las propiedades del record CYBFAV.
        ///        El mapeo de familia/grupo usa switch expression en vez de 3 if-else.
        /// </summary>
        private static Data GenerarPropiedadesAdicionales(CYBFAV item)
        {
            var props = new Data
            {
                Field = "PropiedadesAdicionales",
                DataList = new List<Data>()
            };

            // valCuentaOrigen — ANTES: item.GetValue("NUMCTAO")
            var valCuentaOrigen = new Data
            {
                HasData = true,
                Field = "PropiedadAdicional",
                DataList = new List<Data>
        {
            new Data { HasData = true, Field = "valNombre", Value = "valCuentaOrigen" },
            new Data { HasData = true, Field = "valValor", Value = item.NumeroCuentaOrigen?.Trim() }
        }
            };
            props.DataList.Add(valCuentaOrigen);

            // Familia y grupo según tipo de cuenta destino
            // ANTES: 3 bloques if-else comparando codTipoCuentaDestino.Trim() == "1", "6", else
            // AHORA: switch expression con tuple deconstruction
            var tipoCuenta = item.TipoCuentaDestino?.Trim();
            var (grupo, codigoProducto) = tipoCuenta switch
            {
                "1" => ("CTA01", "1"),
                "6" => ("CTA02", "6"),
                _ => ("CTA03", tipoCuenta ?? "")
            };

            props.DataList.Add(GenProp("familia", "CTAS"));
            props.DataList.Add(GenProp("grupo", grupo));
            props.DataList.Add(GenProp("codigoProducto", codigoProducto));
            props.DataList.Add(GenProp("monedaOrigen", item.MonedaOrigen?.Trim()));
            props.DataList.Add(GenProp("tipoCtaDestino", item.CodTipoTransaccion?.Trim()));
            props.DataList.Add(GenProp("tipoProductoDestino", item.TipoCuentaDestino?.Trim()));
            props.DataList.Add(GenProp("tipoCtaOrigen", item.TipoCuentaOrigen?.Trim()));

            return props;
        }


        /// <summary>
        /// Helper para crear nodos PropiedadAdicional con estructura valNombre/valValor.
        /// REEMPLAZA: método GenProp() de la clase PropiedadesAdicionales.
        /// Misma estructura, solo se movió aquí como método estático privado.
        /// </summary>
        private static Data GenProp(string nombre, string valor) => new Data
        {
            HasData = true,
            Field = "PropiedadAdicional",
            DataList = new List<Data>
    {
        new Data { HasData = true, Field = "valNombre", Value = nombre },
        new Data { HasData = true, Field = "valValor", Value = valor }
    }
        };


    }
}
