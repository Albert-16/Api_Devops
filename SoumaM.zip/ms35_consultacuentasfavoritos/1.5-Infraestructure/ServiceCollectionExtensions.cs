﻿using System;
using System.Collections.Generic;
using System.Text;
using Infraestructure.Repository;
using Infraestructure.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Infraestructure
{
    public static partial class ServiceCollectionExtensions
    {
        public static IServiceCollection AddInfraestructureServices(this IServiceCollection services)
        {
            //Registrar los servicios de dependencia de la libreria
            services.AddScoped<IRepository, InfraestructureRepository>();
            return services;
        }
    }

}
