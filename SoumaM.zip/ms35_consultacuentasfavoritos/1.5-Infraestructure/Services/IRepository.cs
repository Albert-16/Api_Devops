﻿using Domain.Models;
using FastServer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infraestructure.Services
{
    public interface IRepository
    {
        Task<DataTransferObject> DoExecute(Data dataRequest, Guid requestId);
    }
}
