﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UtilesAndHelpers.Helpers
{
    public static class StringExtensions
    {
        /// <summary>
        /// Decodifica una cadena en Base64 a texto plano usando UTF8.
        /// </summary>
        /// <param name="base64String">La cadena codificada.</param>
        /// <returns>La cadena decodificada o string.Empty si es nula.</returns>
        public static string DecodeBase64(this string base64String)
        {
            if (string.IsNullOrEmpty(base64String))
                return string.Empty;

            try
            {
                byte[] data = Convert.FromBase64String(base64String);
                return Encoding.UTF8.GetString(data);
            }
            catch (FormatException)
            {
                // Manejo de error si la cadena no es un Base64 válido
                return "Error: Formato Base64 no válido.";
            }
        }
    }
    public class DecodeBase64Safe
    {
        public string Decode(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "";

            // limpia espacios/saltos de línea
            var s = input.Trim().Replace("\r", "").Replace("\n", "").Replace(" ", "");

            // corrige padding si falta
            int mod = s.Length % 4;
            if (mod != 0) s = s.PadRight(s.Length + (4 - mod), '=');

            try
            {
                var bytes = Convert.FromBase64String(s);
                return Encoding.UTF8.GetString(bytes);
            }
            catch
            {
                // si no era base64 válido, devuelve el original
                return input;
            }
        }
    }
}
