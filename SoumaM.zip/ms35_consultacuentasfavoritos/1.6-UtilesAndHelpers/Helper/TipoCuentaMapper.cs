﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UtilesAndHelpers.Helper
{
    public static class TipoCuentaMapper
    {
        public static string Mapear(string codigo) => codigo switch
        {
            "P" => "50", //PRESTAMOS
            "S" => "60", //SINPE
            "T" => "89", //TARJETAS DE CREDITO
            "G" => "G", //SEGUROS
            _ => "A" //TODOS LOS PRODUCTOS
        };
    }
}
