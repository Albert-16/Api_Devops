# MS35_ConsultaCuentasFavoritos

Consulta Cuentas Inscritas 